# Automated-Ticket-Distribution-System
This project aims to improve how IT service teams manage and distribute support tickets. The system leverages Machine Learning (ML) and Natural Language Processing (NLP) to automatically analyze, classify, and assign tickets to agents based on complexity, workload, and expertise.
