import os
import pandas as pd
import joblib
import seaborn as sns
import matplotlib.pyplot as plt
from pymongo import MongoClient
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# ========== CONFIGURATION ==========
MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "Automated-Ticket-Distribution-System"
DATA_DIR = "scripts"
MODEL_DIR = "model"

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

# ========== CONNECT TO MONGODB ==========
client = MongoClient(MONGO_URI)
db = client[DB_NAME]

tickets = list(db.tickets.find({
    "status": "resolved",
    "assignedTo": {"$ne": None}
}))
agents_cursor = db.agents.find()
agents = {str(agent["_id"]): agent for agent in agents_cursor}

print(f"✅ Fetched {len(tickets)} resolved tickets")
print(f"✅ Fetched {len(agents)} agents")

# ========== MAPPINGS ==========
priority_map = {'low': 0, 'medium': 1, 'high': 2, 'critical': 3}
complexity_map = {'simple': 0, 'moderate': 1, 'complex': 2}

# ========== DATA PREPARATION ==========
data = []
for t in tickets:
    assigned_str = str(t.get("assignedTo"))
    agent = agents.get(assigned_str)
    if not agent:
        print(f"⚠️ Agent not found for ticket {t.get('_id')} → skipping")
        continue

    tags = t.get("tags", [])
    domain = t.get("domain", "")
    agent_skills = list(map(str.lower, agent.get("skills", [])))
    agent_domains = list(map(str.lower, agent.get("domainExpertise", [])))

    if not tags or not agent_skills:
        continue

    data.append({
        "priority": priority_map.get(t.get("priority", "medium"), 1),
        "complexity": complexity_map.get(t.get("complexity", "moderate"), 1),
        "skill_match": len(set(tags).intersection(set(agent_skills))),
        "domain_match": len(set([domain.lower()]).intersection(set(agent_domains))),
        "workload": agent.get("workload", 0),
        "experience": agent.get("experience", 0),
        "avg_rating": agent.get("avgCustomerRating", 0),
        "avg_resolution": agent.get("avgResolutionTime", 0),
        "resolved_count": len(agent.get("ticketHistory", [])),
        "assigned": assigned_str
    })

df = pd.DataFrame(data)
if df.empty:
    raise ValueError("❌ No valid training data found.")

# Save raw data
df.to_csv(os.path.join(DATA_DIR, "agent_training_data.csv"), index=False)
print("✅ Training data saved")

# ========== LABEL ENCODING ==========
label_encoder = LabelEncoder()
df["assigned_encoded"] = label_encoder.fit_transform(df["assigned"])
joblib.dump(label_encoder, os.path.join(MODEL_DIR, "label_encoder.pkl"))
joblib.dump(dict(zip(label_encoder.classes_, label_encoder.transform(label_encoder.classes_))),
            os.path.join(MODEL_DIR, "agent_label_map.pkl"))

# ========== SPLIT DATA ==========
X = df.drop(columns=["assigned", "assigned_encoded"])
y = df["assigned_encoded"]

if len(df) < 5:
    raise ValueError("❌ Not enough data to train.")

sss = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
for train_idx, test_idx in sss.split(X, y):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

# ========== TRAIN MODEL ==========
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# ========== EVALUATE MODEL ==========
y_pred = model.predict(X_test)
print("📊 Classification Report:")
print(classification_report(y_test, y_pred))
print("✅ Accuracy:", accuracy_score(y_test, y_pred))

# ========== CONFUSION MATRIX ==========
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(10, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.show()

# ========== FEATURE IMPORTANCE ==========
print("📌 Feature Importances:")
for name, score in zip(X.columns, model.feature_importances_):
    print(f"   {name}: {score:.4f}")

# ========== SAVE MODEL ==========
joblib.dump(model, os.path.join(MODEL_DIR, "agent_assignment_model.pkl"))
print("✅ Model saved to model/agent_assignment_model.pkl")

# ========== OPTIONAL: HYPERPARAMETER TUNING ==========
# from sklearn.model_selection import GridSearchCV
# params = {
#     "n_estimators": [100, 200],
#     "max_depth": [10, 20, None],
#     "min_samples_split": [2, 5],
#     "min_samples_leaf": [1, 2]
# }
# grid = GridSearchCV(RandomForestClassifier(random_state=42), param_grid=params, cv=3, scoring="f1_weighted")
# grid.fit(X_train, y_train)
# print("🔍 Best Params:", grid.best_params_)
# model = grid.best_estimator_
