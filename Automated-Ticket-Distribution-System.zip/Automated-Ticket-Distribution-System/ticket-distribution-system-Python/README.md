# Python NLP Service for Ticket Analysis

This FastAPI-based microservice performs automatic ticket classification using NLP:
- Extracts tags from subject/description
- Predicts category using zero-shot classification (BART)
- Computes complexity and urgency

## Endpoints

- POST `/analyze`: Analyze a ticket (returns tags, category, complexity, priority)

## Run

```bash
uvicorn app.main:app --reload --port 8000
```

## Docker

```bash
docker build -t nlp-service .
docker run -p 8000:8000 nlp-service
```
