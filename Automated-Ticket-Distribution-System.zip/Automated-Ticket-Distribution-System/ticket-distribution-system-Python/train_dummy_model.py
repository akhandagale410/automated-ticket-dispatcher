import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier

# 🔹 Dummy training data (X = features, y = labels)
# Features: [priority, complexity, skill_match, workload, experience]
X = np.array([
    [1, 1, 2, 5, 3],
    [2, 1, 1, 3, 2],
    [3, 2, 3, 4, 5],
    [1, 2, 0, 6, 1],
    [2, 0, 2, 2, 2]
])
y = [0, 1, 1, 0, 1]  # 1 = best-fit agent, 0 = not best-fit

# 🔹 Train simple classifier
model = RandomForestClassifier()
model.fit(X, y)

# 🔹 Save the model
joblib.dump(model, "agent_assignment_model.pkl")
print("✅ Model saved as agent_assignment_model.pkl")
