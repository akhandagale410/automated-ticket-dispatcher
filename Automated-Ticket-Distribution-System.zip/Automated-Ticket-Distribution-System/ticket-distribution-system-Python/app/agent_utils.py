from app.redis_client import get_agent_from_cache, set_agent_to_cache
from datetime import datetime
from pymongo import MongoClient

def serialize_ticket(ticket):
    ticket["_id"] = str(ticket["_id"])
    if "assignedTo" in ticket and ticket["assignedTo"]:
        ticket["assignedTo"] = str(ticket["assignedTo"])
    for k, v in ticket.items():
        if isinstance(v, datetime):
            ticket[k] = v.isoformat()
    return ticket

def get_agents_from_db():
    client = MongoClient("mongodb://localhost:27017")
    db = client["Automated-Ticket-Distribution-System"]

    agents = db.agents.find({"availability": "online"})
    tickets = list(db.tickets.find({"status": {"$in": ["open", "assigned"]}}))

    agent_lookup = {}

    for agent in agents:
        agent_id = str(agent["_id"])

        # Try to fetch from Redis
        cached = get_agent_from_cache(agent_id)
        if cached:
            agent_lookup[agent_id] = cached
            continue

        # Else calculate workload and cache it
        agent_tickets = [serialize_ticket(t) for t in tickets if str(t.get("assignedTo")) == agent_id]
        workload = len(agent_tickets)

        data = {
            "skills": agent.get("skills", []),
            "domainExpertise": agent.get("domainExpertise", []),
            "workload": workload,
            "experience": agent.get("experience", 0),
            "ticketHistory": agent_tickets
        }

        set_agent_to_cache(agent_id, data)
        agent_lookup[agent_id] = data

    return agent_lookup
