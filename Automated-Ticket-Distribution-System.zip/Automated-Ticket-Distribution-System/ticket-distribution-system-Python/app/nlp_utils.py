import spacy
import numpy as np
import joblib
import logging
import pandas as pd
from transformers import pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from app.agent_utils import get_agents_from_db

# Load pre-trained models
model = joblib.load("model/agent_assignment_model.pkl")
label_encoder = joblib.load("model/label_encoder.pkl")

# Logging setup
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Load NLP models
nlp = spacy.load("en_core_web_sm")
classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

# Priority and complexity mappings
priority_map = {"low": 0, "medium": 1, "high": 2, "critical": 3}
complexity_map = {"simple": 0, "moderate": 1, "complex": 2}

def extract_tags(text):
    """Extract relevant tags (nouns/proper nouns) using SpaCy."""
    doc = nlp(text)
    return list(set(
        token.lemma_.lower() for token in doc
        if token.pos_ in ["NOUN", "PROPN"] and not token.is_stop
    ))

def similarity(text1, text2_list):
    """Compute cosine similarity between text1 and a list of text2s."""
    if not text2_list:
        return 0.0
    texts = [text1] + text2_list
    tfidf = TfidfVectorizer().fit_transform(texts)
    sim_scores = cosine_similarity(tfidf[0:1], tfidf[1:]).flatten()
    return float(np.max(sim_scores)) if len(sim_scores) > 0 else 0.0

def check_previous_assignment(subject, description, agent_lookup, threshold=0.8):
    """Return agent ID if they handled a similar ticket recently (above similarity threshold)."""
    text_to_check = f"{subject} {description}"
    best_match_agent_id = None
    best_similarity = 0.0

    for agent_id, agent in agent_lookup.items():
        history = agent.get("ticketHistory", [])
        if not history:
            continue

        history_texts = [f"{t.get('subject', '')} {t.get('description', '')}" for t in history]
        sim = similarity(text_to_check, history_texts)

        if sim > best_similarity and sim >= threshold:
            best_similarity = sim
            best_match_agent_id = agent_id

    if best_match_agent_id:
        logger.info(f"Similar ticket previously handled by Agent {best_match_agent_id} (similarity: {best_similarity:.2f})")

    return best_match_agent_id

def assign_agent(tags, description, priority, complexity, agent_lookup, subject=None):
    """Selects the best agent based on skills, experience, domain, workload, and similarity."""
    agent_ids = list(agent_lookup.keys())
    scores = []

    # Step 1: Prioritize previous agent match (if workload is reasonable)
    prev_agent_id = check_previous_assignment(subject, description, agent_lookup)
    if prev_agent_id:
        prev_agent = agent_lookup.get(prev_agent_id, {})
        prev_workload = prev_agent.get("workload", 0)

        if prev_workload < 5:  # Threshold to avoid overloaded agent
            logger.info(f"Reassigning to previously matched agent {prev_agent_id} (workload: {prev_workload})")
            return prev_agent_id
        else:
            logger.info(f"Previous agent {prev_agent_id} skipped due to high workload ({prev_workload})")

    # Step 2: Score-based agent selection
    for agent_id in agent_ids:
        agent = agent_lookup[agent_id]
        skills = agent.get("skills", [])
        domains = agent.get("domainExpertise", [])
        workload = agent.get("workload", 0)
        experience = agent.get("experience", 0)
        history = agent.get("ticketHistory", [])

        # Matches
        skill_match = len(set(tags).intersection(set(map(str.lower, skills))))
        domain_match = len(set(tags).intersection(set(map(str.lower, domains))))

        # History similarity
        history_tags = [tag for t in history for tag in t.get("tags", [])]
        history_descs = [f"{t.get('subject', '')} {t.get('description', '')}" for t in history]

        tag_similarity = similarity(" ".join(tags), [" ".join(history_tags)]) if history_tags else 0
        desc_similarity = similarity(description, history_descs) if history_descs else 0

        # Feature vector
        feature_vector = np.array([
            priority_map.get(priority, 1),
            complexity_map.get(complexity, 1),
            skill_match,
            domain_match,
            -workload,  # negative value to prioritize lower workload
            experience,
            tag_similarity,
            desc_similarity
        ])

        # Weights (tune as needed)
        weights = np.array([1, 1, 2, 2, 3, 1, 2, 2])
        score = feature_vector @ weights
        scores.append(score)

        logger.info(f"Agent {agent_id}: Score={score:.2f}, SkillMatch={skill_match}, DomainMatch={domain_match}, "
                    f"Workload={workload}, Experience={experience}, TagSim={tag_similarity:.2f}, DescSim={desc_similarity:.2f}")

    if not scores:
        return None

    best_index = int(np.argmax(scores))
    best_agent_id = agent_ids[best_index]
    logger.info(f"Best agent selected based on score: {best_agent_id}")
    return best_agent_id

def analyze_ticket(subject, description):
    """Analyzes a ticket and returns metadata + assigned agent."""
    text = f"{subject} {description}"
    tags = extract_tags(text)

    # Complexity estimation
    complexity = "moderate"
    if len(text) > 200:
        complexity = "complex"
    elif len(text) < 80:
        complexity = "simple"

    # Category classification
    candidate_labels = [
        "Login", "Access", "LDAP", "Network", "Backup", "Call", "Crash", "Voicemail", "Integration",
        "SAML", "SSO", "Token Expiry", "One-X", "Session Manager", "Call Drop", "No Audio", "Call Quality", "Codec Issue",
        "Firewall", "Port Block", "NAT", "VPN", "WebSocket",
        "Timeout", "HTTP 500", "Unavailable", "Service Down", "Registration Failure",
        "AADS", "AAWG", "Presence", "Configuration", "Provisioning", "Cert Error", "Reverse Proxy", "UCID",
        "Database", "Replication", "Log Rotation", "Storage Full", "Backup Failure", "Restore Failure",
        "Performance", "Latency", "Throughput", "Packet Loss", "Jitter", "QoS", "SLA",
        "Monitoring", "Alert", "Notification", "Report", "Dashboard", "Analytics"
    ]
    classification = classifier(text, candidate_labels)
    category = classification["labels"][0] if classification["labels"] else "General"

    # Domain detection
    domain_keywords = {
        "Unified Communications": ["call", "voicemail", "call drop", "conference", "one-x", "smgr", "session manager"],
        "Directory Services": ["ldap", "directory", "ad", "active directory"],
        "Presence Services": ["presence", "ps"],
        "AAWG": ["aawg", "web gateway", "web client", "awagent", "aawg server", "aawg error", "web rtc", "wfo", "chat"],
        "AADS": ["aads", "device services", "endpoint provisioning", "service discovery", "persistence", "dadmin", "uds", "device profile", "login uri", "aads config"],
        "Security": ["cert", "certificate", "token", "sso", "saml", "authentication"],
        "Media Services": ["codec", "media", "no audio", "jitter", "packet loss", "qos", "rtp", "srtp"],
        "Monitoring & Analytics": ["dashboard", "alert", "monitoring", "analytics", "report", "metric"],
        "Network": ["vpn", "nat", "firewall", "port block", "websocket", "ipsec", "dns", "routing"],
        "Storage & Backup": ["backup", "restore", "storage", "log rotation", "database", "replication", "disk full", "snapshot"]
    }

    domain = "General"
    for dom, keywords in domain_keywords.items():
        if any(tag in tags for tag in keywords):
            domain = dom
            break

    # Priority detection (simplified keyword-based)
    priority = "high" if "urgent" in text.lower() or "critical" in text.lower() else "medium"

    # Fetch agents and assign one
    agent_lookup = get_agents_from_db()
    assigned_agent_id = assign_agent(tags, description, priority, complexity, agent_lookup, subject)

    # Return full analysis
    return {
        "complexity": complexity,
        "category": category,
        "tags": tags,
        "domain": domain,
        "priority": priority,
        "assignedAgentId": assigned_agent_id
    }
