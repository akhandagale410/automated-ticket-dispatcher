# Configuration and environment values
MODEL_NAME = "facebook/bart-large-mnli"
