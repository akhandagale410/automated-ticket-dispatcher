from fastapi import FastAPI
from pydantic import BaseModel
from app.nlp_utils import analyze_ticket
import subprocess

app = FastAPI()

# 🔹 NLP Input Model
class TicketInput(BaseModel):
    subject: str
    description: str

# ✅ Existing Analyzer Endpoint
@app.post("/analyze")
async def analyze(input: TicketInput):
    try:
        result = analyze_ticket(input.subject, input.description)
        return result
    except Exception as e:
        print(f"[ERROR] Analyzer failed: {str(e)}")
        return {"error": str(e)}

# ✅ New: Trigger ML Training Endpoint
@app.post("/train-model")
async def train_model():
    try:
        output = subprocess.check_output(["python", "scripts/train_agent_model.py"], stderr=subprocess.STDOUT)
        return {
            "status": "success",
            "output": output.decode("utf-8")
        }
    except subprocess.CalledProcessError as e:
        return {
            "status": "error",
            "message": e.output.decode("utf-8")
        }
