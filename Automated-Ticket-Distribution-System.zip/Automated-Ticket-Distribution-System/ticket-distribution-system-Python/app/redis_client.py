import redis
import json
from bson import ObjectId
from datetime import datetime

# Connect to Redis
redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

# Serializer for unsupported types
def json_serializer(obj):
    if isinstance(obj, ObjectId):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")

# Save agent data to Redis
def set_agent_to_cache(agent_id, data, ttl=300):
    key = f"agent:{agent_id}"
    redis_client.setex(key, ttl, json.dumps(data, default=json_serializer))

# Retrieve agent data from Redis
def get_agent_from_cache(agent_id):
    key = f"agent:{agent_id}"
    if redis_client.type(key) != 'string':
        redis_client.delete(key)
        return None
    data = redis_client.get(key)
    return json.loads(data) if data else None

# Invalidate cache
def invalidate_agent_cache(agent_id):
    redis_client.delete(f"agent:{agent_id}")
