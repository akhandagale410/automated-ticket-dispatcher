from pydantic import BaseModel

class TicketInput(BaseModel):
    subject: str
    description: str
