import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CustomerService {
  private baseUrl = 'http://localhost:3000/api/customers';

  constructor(private http: HttpClient) {}

  // 🔹 Get all customers
  getCustomers(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  // 🔹 Create a new customer (standard route, not '/register')
  createCustomer(data: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, data);
  }

  // 🔹 Update customer details
  updateCustomer(id: string, data: any): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/${id}`, data);
  }

  // 🔹 Get all tickets created by a customer
  getCustomerTickets(customerId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/${customerId}/tickets`);
  }

  // 🔹 Submit new ticket from customer
  createCustomerTicket(ticketData: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/tickets`, ticketData);
  }
  deleteCustomer(id: string) {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
