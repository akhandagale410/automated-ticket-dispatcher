import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export interface UserProfile {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  createdAt?: string;
  updatedAt?: string;
}
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl = 'http://localhost:3000/api/users';

  constructor(private http: HttpClient) {}

  login(credentials: { email: string; password: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, credentials);
  }

  register(userData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, userData);
  }
 // 🔹 Get user by ID
 getUser(id: string): Observable<UserProfile> {
  return this.http.get<UserProfile>(`${this.baseUrl}/${id}`);
}

// 🔹 Update user profile
updateUser(id: string, user: Partial<UserProfile>): Observable<UserProfile> {
  return this.http.put<UserProfile>(`${this.baseUrl}/${id}`, user);
}
  logout(): void {
    localStorage.removeItem('token');
  }
  getRole(): string {
    return localStorage.getItem('role') || '';
  }
  isAuthenticated(): boolean {
    return !!localStorage.getItem('token');
  }
}
