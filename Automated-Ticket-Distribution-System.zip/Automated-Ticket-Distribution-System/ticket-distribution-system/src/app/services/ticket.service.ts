import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class TicketService {


  private baseUrl = 'http://localhost:3000/api/tickets';
  private analyticsUrl = 'http://localhost:3000/api/analytics';

  constructor(private http: HttpClient) {}

  // 🔹 Get all tickets (admin or filtered in frontend)
  getTickets(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}`);
  }
  addInternalNote(ticketId: string, note: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/${ticketId}/internal-note`, note);
  }
  // 🔹 Get a ticket by ID
  getTicketById(id: string): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${id}`);
  }
  deleteTicket(ticketId: string) {
    return this.http.delete(`${this.baseUrl}/${ticketId}`);
  }
  // 🔹 Create a new ticket
  createTicket(ticketData: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, ticketData);
  }

  // 🔹 Update ticket (admin or agent)
  updateTicket(id: string, payload: any): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/${id}`, payload);
  }

  // 🔹 Escalate a ticket
  escalateTicket(id: string, reason: string): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/${id}/escalate`, { escalationReason: reason });
  }

  // 🔹 Attach files to a ticket
  attachFiles(id: string, files: File[]): Observable<any> {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    return this.http.post<any>(`${this.baseUrl}/${id}/attach`, formData);
  }

  // 🔹 Agent-specific ticket update (status/internal note)
  agentUpdateTicket(id: string, payload: any): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/${id}/agent-update`, payload);
  }

  // 🔹 Get SLA-breaching tickets
  getSLABreaches(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/sla/violations`);
  }
  getOverdueCount(agentId: string) {
    return this.http.get<{ count: number }>(`${this.baseUrl}/overdue/${agentId}`);
  }

  // 🔹 Get Escalated tickets
  getEscalatedTickets(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/escalated`);
  }

  // 🔹 Get CSAT (Customer Satisfaction) stats
  getCSATStats(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/analytics/csat`);
  }

  // 🔹 Get Linked Incidents grouped by root cause
  getLinkedIncidents(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/linked-incidents`);
  }
  getAgentLoad(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/workload`);
  }
  getAllTicketsForAdmin() {
    return this.http.get<any[]>(`${this.baseUrl}/admin/all`);
  }
  assignTicketManually(payload: { ticketId: string, agentId: string }) {
    return this.http.post(`${this.baseUrl}/admin/assign`, payload);
  }
  submitFeedback(ticketId: string, rating: number) {
    return this.http.put(`${this.baseUrl}/${ticketId}/feedback`, { rating });
  }

}
