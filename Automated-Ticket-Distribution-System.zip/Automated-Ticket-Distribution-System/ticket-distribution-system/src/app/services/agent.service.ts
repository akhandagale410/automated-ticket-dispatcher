import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AgentService {
  private baseUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  // 🔹 Get tickets assigned to the agent
  getAssignedTickets(agentId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/agents/${agentId}/tickets`);
  }

  // 🔹 Get agent profile by ID
  getAgentById(agentId: string): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/agents/${agentId}`);
  }

  // 🔹 Update ticket as agent
  updateTicketAsAgent(ticketId: string, payload: any): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/tickets/${ticketId}/agent-update`, payload);
  }

  // 🔹 Get all agents
  getAgents(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/agents`);
  }

  // 🔹 Create agent with user
  createAgent(payload: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/agents/full-create`, payload);
  }

  // 🔹 Update agent and user info by userId
  updateAgent(userId: string, payload: any): Observable<any> {
    return this.http.patch<any>(`${this.baseUrl}/agents/full-update/${userId}`, payload);
  }
  deleteAgent(agentId: string) {
    return this.http.delete(`${this.baseUrl}/agents/${agentId}`);
  }
}
