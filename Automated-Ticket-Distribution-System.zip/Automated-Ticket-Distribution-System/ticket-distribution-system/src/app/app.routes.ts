import { Routes } from '@angular/router';

import { LoginComponent } from './components/auth/login/login.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard/dashboard.component';
import { TicketDashboardComponent } from './components/dashboard/ticket-dashboard/ticket-dashboard.component';
import { AgentTicketsComponent } from './components/dashboard/agent-tickets/agent-tickets.component';

import { ProfileManagementComponent } from './components/dashboard/profile-management/profile-management.component';
import { ManageAgentComponent } from './components/admin/agent/manage-agent.component';
import { ManageCustomerComponent } from './components/admin/customer/manage-customer.component';
import { ViewTicketsComponent } from './components/dashboard/view-tickets/view-tickets.component';
import { ViewCustomerTicketsComponent } from './components/customer/view-customer-tickets/view-customer-tickets.component';
import { AdminTicketAssignComponent } from './components/admin/admin-ticket-assign/admin-ticket-assign.component';
import { CustomerTicketsComponent } from './components/dashboard/customer-tickets/customer-tickets.component';
export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' }, // Default route to Login
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
  },
  {
    path: 'tickets',
    component: TicketDashboardComponent,
  },
  { path: 'myTickets', component: AgentTicketsComponent},
  { path: 'manageAgent', component: ManageAgentComponent},
  {path:'profile', component: ProfileManagementComponent},
  {path:'managecustomer', component: ManageCustomerComponent},
  { path: 'agent-tickets/:agentId', component: ViewTicketsComponent },
  { path: 'customer-tickets/:id',   component: ViewCustomerTicketsComponent },
  { path: 'create-tickets',   component: CustomerTicketsComponent},
  { path: 'admin/tickets/assign', component: AdminTicketAssignComponent },
  { path: '**', redirectTo: '/login' },
];
