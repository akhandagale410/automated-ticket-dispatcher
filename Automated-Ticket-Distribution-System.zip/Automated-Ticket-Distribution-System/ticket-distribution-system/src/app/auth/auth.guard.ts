import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authRoleGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);

  const token = localStorage.getItem('token');
  const userRole = localStorage.getItem('role');
  const expectedRole = route.data?.['role'];

  if (!token) {
    // Not logged in
    router.navigate(['/login']);
    return false;
  }

  if (!expectedRole || expectedRole === userRole) {
    return true;
  }

  // Logged in, but doesn't have permission
  router.navigate(['/unauthorized']);
  return false;
};

