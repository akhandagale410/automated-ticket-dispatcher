// ✅ manage-customer.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CustomerService } from '../../../services/customer.service';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-manage-customer',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterModule],
  providers: [CustomerService], // ✅ Make service available
  templateUrl: './manage-customer.component.html',
  styleUrls: ['./manage-customer.component.css']
})
export class ManageCustomerComponent implements OnInit {
  customers: any[] = [];
  showForm = false;
  isEditMode = false;
  selectedCustomerId: string | null = null;
  currentPage = 1;
  itemsPerPage = 10;
  customerForm = {
    firstName: '',
    lastName: '',
    email: '',
    password: ''
  };
  toastMessage: string = '';
  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers(): void {
    this.customerService.getCustomers().subscribe({
      next: (res) => this.customers = res,
      error: (err) => console.error('Error loading customers:', err)
    });
  }

  openAddForm(): void {
    this.showForm = true;
    this.isEditMode = false;
    this.selectedCustomerId = null;
    this.customerForm = { firstName: '', lastName: '', email: '', password: '' };
  }

  openEditForm(customer: any): void {
    this.showForm = true;
    this.isEditMode = true;
    this.selectedCustomerId = customer._id;
    this.customerForm = {
      firstName: customer.firstName,
      lastName: customer.lastName,
      email: customer.email,
      password: '' // Leave blank for update
    };
  }

  submitCustomer(): void {
    if (this.isEditMode && this.selectedCustomerId) {
      const payload = {
        firstName: this.customerForm.firstName,
        lastName: this.customerForm.lastName,
        email: this.customerForm.email
      };
      this.customerService.updateCustomer(this.selectedCustomerId, payload).subscribe({
        next: () => {
          this.loadCustomers();
          this.showForm = false;
        },
        error: (err) => console.error('Update error:', err)
      });
    } else {
      this.customerService.createCustomer(this.customerForm).subscribe({
        next: () => {
          this.loadCustomers();
          this.showForm = false;
        },
        error: (err) => console.error('Create error:', err)
      });
    }
  }
  get totalPages(): number {
    return Math.ceil(this.customers.length / this.itemsPerPage);
  }
  get totalPagesArray(): number[] {
    return Array(this.totalPages).fill(0).map((_, i) => i + 1);
  }
  get paginatedCustomers(): any[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.customers.slice(start, start + this.itemsPerPage);
  }
  changePage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  deleteCustomer(id: string): void {
    if (confirm('Are you sure you want to delete this customer?')) {
      this.customerService.deleteCustomer(id).subscribe({
        next: () => {
          this.toastMessage = 'Customer deleted successfully ✅';
          this.loadCustomers();
          setTimeout(() => this.toastMessage = '', 3000);
        },
        error: (err) => console.error('Delete error:', err)
      });
    }
  }
}
