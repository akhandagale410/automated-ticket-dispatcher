import { Component } from '@angular/core';
import { TicketService } from '../../../services/ticket.service';
import { AgentService } from '../../../services/agent.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-ticket-assign',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-ticket-assign.component.html',
  styleUrl: './admin-ticket-assign.component.css'
})
export class AdminTicketAssignComponent {
  tickets: any[] = [];
  agents: any[] = [];
  filteredTickets: any[] = [];
  currentPage = 1;
  pageSize = 10;
  totalPages = 1;
  selectedAgent: string = '';
toastMessage: string = '';

  constructor(private ticketService: TicketService, private agentService: AgentService) {}

  ngOnInit(): void {

    this.loadTickets();
    this.loadAgents();
  }

  loadTickets(): void {
    this.ticketService.getTickets().subscribe({
      next: (res:any) => {
        // ✅ Confirm it's an array

        // Safely access ticket list
        const tickets = Array.isArray(res.data) ? res.data : [];

        // Filter out resolved and closed
        this.tickets = tickets.filter((t:any) => t.status !== 'resolved' && t.status !== 'closed');

        // Prepare filtered list and paginate
        this.filteredTickets = [...this.tickets];
        this.updatePagination();
      },
      error: (err) => console.error('Failed to load tickets:', err)
    });
  }

  loadAgents(): void {
    this.agentService.getAgents().subscribe({
      next: (res) => this.agents = res,
      error: (err) => console.error('Failed to load agents:', err)
    });
  }

 assignTicket(ticketId: string, agentId: string): void {
  const payload = {
    assignedTo: agentId,
    status: 'assigned',
    changedBy: 'admin'
  };

  this.ticketService.updateTicket(ticketId, payload).subscribe({
    next: () => {
      this.toastMessage = '🎉 Ticket assigned successfully!';
      this.loadTickets(); // Refresh list
      setTimeout(() => this.toastMessage = '', 3000); // Hide after 3s
    },
    error: (err) => {
      console.error('Error assigning ticket:', err);
      this.toastMessage = '❌ Failed to assign ticket.';
      setTimeout(() => this.toastMessage = '', 3000);
    }
  });
}

  updatePagination(): void {
    this.totalPages = Math.ceil(this.filteredTickets.length / this.pageSize);
  }

  get paginatedTickets(): any[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredTickets.slice(start, start + this.pageSize);
  }

  changePage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  getAgentName(agentId: string): string {

    const agent = this.agents.find(a => a._id === agentId || a.userId?._id === agentId);
 // ✅ Confirm agent object
    if (agent?.userId) {
      return `${agent.userId.firstName} ${agent.userId.lastName}`;
    }
    return '';
  }
}
