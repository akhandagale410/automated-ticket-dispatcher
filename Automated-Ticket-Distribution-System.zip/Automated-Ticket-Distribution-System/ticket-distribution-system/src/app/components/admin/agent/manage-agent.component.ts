import { Component, OnInit } from '@angular/core';
import { AgentService } from '../../../services/agent.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
declare var bootstrap: any;

@Component({
  selector: 'app-manage-agent',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterModule],
  templateUrl: './manage-agent.component.html',
  styleUrls: ['./manage-agent.component.css']
})
export class ManageAgentComponent implements OnInit {
  agents: any[] = [];
  isEditMode = false;
  selectedAgent: any = null;
  toastMessage: string = '';
  pageSize = 4;
currentPage = 1;
paginatedAgents: any[] = [];
  agentForm = {
    firstName: '',
    lastName: '',
    email: '',
    password: '',  // Required only for creation
    role: 'agent',
    skills: '',
    domainExpertise: '',
    experience: 0,
    maxTickets: 5,
    certifications: '',
    availability: 'online'
  };

  constructor(private agentService: AgentService) {}

  ngOnInit(): void {
    this.loadAgents();
  }


  openAddModal(): void {
    this.isEditMode = false;
    this.selectedAgent = null;
    this.agentForm = {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      role: 'agent',
      skills: '',
      domainExpertise: '',
      experience: 0,
      maxTickets: 5,
      certifications: '',
      availability: 'online'
    };
  }

  openEditModal(agent: any): void {
    this.isEditMode = true;
    this.selectedAgent = agent;
    this.agentForm = {
      firstName: agent.userId?.firstName || '',
      lastName: agent.userId?.lastName || '',
      email: agent.userId?.email || '',
      password: '', // Not editable
      role: agent.userId?.role || 'agent',
      skills: agent.skills?.join(', ') || '',
      domainExpertise: agent.domainExpertise?.join(', ') || '',
      experience: agent.experience,
      maxTickets: agent.maxTickets,
      certifications: (agent.certifications || []).join(', '),
      availability: agent.availability || 'online'
    };
  }


  submitAgent(): void {
    const payload: any = {
      firstName: this.agentForm.firstName,
      lastName: this.agentForm.lastName,
      email: this.agentForm.email,
      password:this.agentForm.password,
      role: 'agent',
      skills: this.agentForm.skills.split(',').map(s => s.trim()),
      domainExpertise: this.agentForm.domainExpertise.split(',').map(d => d.trim()),
      experience: this.agentForm.experience,
      certifications: this.agentForm.certifications.split(',').map(c => c.trim()),
      maxTickets: this.agentForm.maxTickets,
      availability: this.agentForm.availability
    };

    if (!this.isEditMode) {
      payload.password = this.agentForm.password; // Required for creation

      this.agentService.createAgent(payload).subscribe({
        next: () => {
          this.loadAgents();
          this.closeModal();
        },
        error: (err) => console.error('Error creating agent:', err)
      });
    } else {
      const userId = this.selectedAgent.userId?._id || this.selectedAgent.userId;
      this.agentService.updateAgent(userId, payload).subscribe({
        next: () => {
          this.loadAgents();
          this.closeModal();
        },
        error: (err) => console.error('Error updating agent:', err)
      });
    }
  }


  // closeModal(): void {
  //   const modalElement = document.getElementById('agentModal');
  //   if (modalElement) {
  //     const modalInstance = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
  //     modalInstance.hide();
  //   }
  // }
  closeModal(): void {
    const modalElement = document.getElementById('agentModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.hide(); // Show + hide to reset and close cleanly
      modalElement.classList.remove('show');
      modalElement.style.display = 'none';
      document.body.classList.remove('modal-open');
      const backdrops = document.querySelectorAll('.modal-backdrop');
      backdrops.forEach(b => b.remove());
    }
  }
  deleteAgent(agentId: string): void {
    if (confirm('Are you sure you want to delete this agent?')) {
      this.agentService.deleteAgent(agentId).subscribe({
        next: () => {
          this.toastMessage = 'Agent deleted successfully.';
          setTimeout(() => this.toastMessage = '', 3000);
        },
        error: (err) => {
          console.error('Error deleting agent:', err);
          alert('Failed to delete agent. Please try again.');
        }
      });
    }
  }
  get totalPages(): number {
    return Math.ceil(this.agents.length / this.pageSize);
  }

  get totalPagesArray(): number[] {
    return Array(this.totalPages)
      .fill(0)
      .map((_, i) => i + 1);
  }

  changePage(page: number) {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
    this.paginateAgents();
  }

  paginateAgents() {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedAgents = this.agents.slice(start, end);
  }

  // Call this after loading agents
  loadAgents(): void {
    this.agentService.getAgents().subscribe({
      next: (res) => {
        this.agents = res;
        this.changePage(1); // Reset to first page
      },
      error: (err) => console.error('Error loading agents', err)
    });
  }
}
