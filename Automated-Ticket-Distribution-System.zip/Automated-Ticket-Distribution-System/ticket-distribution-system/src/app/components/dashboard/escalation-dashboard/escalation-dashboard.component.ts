import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TicketService } from '../../../services/ticket.service';

import { ChangeDetectorRef } from '@angular/core';
@Component({
  standalone: true,
  selector: 'app-escalation-dashboard',
  imports: [CommonModule],
  templateUrl: './escalation-dashboard.component.html'
})
export class EscalationDashboardComponent implements OnInit {
  escalatedTickets: any[] = [];
  isLoading = true;
  error: string = '';


  constructor(private ticketService: TicketService ,private cdRef: ChangeDetectorRef) {}

  ngOnInit() {
    this.ticketService.getEscalatedTickets().subscribe({
      next: (data) => {
        this.escalatedTickets = data.filter(ticket => ticket.status !== 'resolved');

      },
      error: (err) => {
        console.error('Failed to load escalated tickets', err);
        this.error = 'Failed to load escalated tickets';

      }
    });
  }
}
