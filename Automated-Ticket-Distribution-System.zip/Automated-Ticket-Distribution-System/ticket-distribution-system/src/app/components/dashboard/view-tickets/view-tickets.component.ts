import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { AgentService } from '../../../services/agent.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-view-tickets',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './view-tickets.component.html',
  styleUrl: './view-tickets.component.css'
})
export class ViewTicketsComponent implements OnInit {
  agentId!: string;
  tickets: any[] = [];
  filteredTickets: any[] = [];
  paginatedTickets: any[] = [];

  searchQuery: string = '';

  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 1;
  agentName: string = 'Agent';
  constructor(
    private route: ActivatedRoute,
    private ticketService: AgentService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.agentId = this.route.snapshot.paramMap.get('agentId')!;

    if (this.agentId) {
      this.ticketService.getAgentById(this.agentId).subscribe((agent) => {
        if (agent?.userId?.firstName) {
          this.agentName = `${agent.userId.firstName} ${agent.userId.lastName}`;
        }
      });
    }

  this.fetchAgentTickets();
  }

  fetchAgentTickets() {
    this.ticketService.getAssignedTickets(this.agentId).subscribe((res) => {
      this.tickets = res;
      this.filteredTickets = [...this.tickets];
      this.totalPages = Math.ceil(this.filteredTickets.length / this.pageSize);
      this.updatePaginatedTickets();
    });
  }

  filterTickets() {
    const query = this.searchQuery.toLowerCase();
    this.filteredTickets = this.tickets.filter(ticket =>
      ticket.subject.toLowerCase().includes(query) ||
      ticket.category.toLowerCase().includes(query) ||
      ticket.status.toLowerCase().includes(query)
    );

    this.currentPage = 1;
    this.totalPages = Math.ceil(this.filteredTickets.length / this.pageSize);
    this.updatePaginatedTickets();
  }

  updatePaginatedTickets() {
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.paginatedTickets = this.filteredTickets.slice(start, end);
  }

  changePage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedTickets();
    }
  }

  get totalPagesArray(): number[] {
    return Array(this.totalPages).fill(0).map((_, i) => i + 1);
  }

  goBack() {
    this.location.back();
  }
}
