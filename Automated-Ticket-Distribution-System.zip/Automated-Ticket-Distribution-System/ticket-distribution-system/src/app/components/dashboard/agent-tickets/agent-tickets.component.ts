import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AgentService } from '../../../services/agent.service';
import { Location } from '@angular/common';
import { TicketService } from '../../../services/ticket.service';

@Component({
  selector: 'app-agent-tickets',
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [AgentService],
  templateUrl: './agent-tickets.component.html',
  styleUrls: ['./agent-tickets.component.css']
})
export class AgentTicketsComponent implements OnInit {
  tickets: any[] = [];
  filteredTickets: any[] = [];
  ticketUpdates: { [id: string]: { status: string, internalNote: string } } = {};
  agentId = localStorage.getItem('userId') || '';
  agentProfile: any;
  toastMessage = '';
  searchText = '';
  currentPage = 1;
  pageSize = 5;
  now = new Date();
  selectedStatus: string = '';
  overdueCount = 0;
  expandedNoteId: string | null = null;

  constructor(private agentService: AgentService,private ticketService: TicketService,  private location: Location) {}

  ngOnInit(): void {
    this.loadAgentProfile();
    this.loadTickets();
    this.loadOverdueCount();
  }
  loadOverdueCount() {
    this.ticketService.getOverdueCount(this.agentId).subscribe({
      next: (res) => {
        this.overdueCount = res.count;
        console.log('Overdue count:', this.overdueCount);
        this.calculateStats();
      },
      error: (err) => console.error('Failed to load overdue count', err)
    });
  }
  scrollToBottom(element: HTMLElement): void {
    setTimeout(() => {
      element.scrollTop = element.scrollHeight;
    }, 0);
  }
  loadTickets(): void {
    this.agentService.getAssignedTickets(this.agentId).subscribe((res) => {
      this.tickets = res;
      this.filteredTickets = [...this.tickets];
      this.prepareTicketUpdates();
      this.calculateStats();
    });
  }

  calculateStats() {
    const assigned = this.tickets.filter(t => t.status === 'assigned').length;
    const inProgress = this.tickets.filter(t => t.status === 'in_progress').length;
    const resolved = this.tickets.filter(t => t.status === 'resolved').length;

const overdueCount = this.overdueCount;
    this.stats = [
      { title: 'Open Tickets', value: assigned, icon: 'bi bi-folder2-open', bg: 'bg-primary' },
      { title: 'In Progress', value: inProgress, icon: 'bi bi-hourglass-split', bg: 'bg-warning' },
      { title: 'Resolved', value: resolved, icon: 'bi bi-check2-circle', bg: 'bg-success' },
      { title: 'Overdue', value:overdueCount , icon: 'bi bi-exclamation-triangle', bg: 'bg-danger' },
    ];
  }

  prepareTicketUpdates(): void {
    this.ticketUpdates = {};
    for (const ticket of this.tickets) {
      this.ticketUpdates[ticket._id] = {
        status: ticket.status,
        internalNote: ''
      };
    }
  }

  toggleNote(ticketId: string): void {
    this.expandedNoteId = this.expandedNoteId === ticketId ? null : ticketId;
  }

  refreshTickets(): void {
    this.loadTickets();
  }

  loadAgentProfile(): void {
    this.agentService.getAgentById(this.agentId).subscribe((res) => {
      this.agentProfile = res;
    });
  }

  applyFilter(): void {
    const search = this.searchText.toLowerCase();
    // this.filteredTickets = this.tickets.filter(t =>
    //   t.subject.toLowerCase().includes(search) ||
    //   t.category?.toLowerCase().includes(search)
    // );
    this.currentPage = 1;
    this.filteredTickets = this.tickets.filter(ticket => {
      const matchesSearch =
        (!this.searchText || ticket.subject?.toLowerCase().includes(this.searchText.toLowerCase()) ||
         ticket.category?.toLowerCase().includes(this.searchText.toLowerCase()));

      const matchesStatus =
        !this.selectedStatus || ticket.status === this.selectedStatus;

      return matchesSearch && matchesStatus;
    });
    this.prepareTicketUpdates();
  }

  get paginatedTickets(): any[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredTickets.slice(start, start + this.pageSize);
  }

  nextPage(): void {
    if (this.currentPage * this.pageSize < this.filteredTickets.length) {
      this.currentPage++;
    }
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  isSlaViolated(ticket: any): boolean {
    return new Date(ticket.slaDeadline) < new Date() && !['resolved', 'closed'].includes(ticket.status);
  }

  submitUpdate(ticketId: string): void {
    const update = this.ticketUpdates[ticketId];
    const newNoteText = update.internalNote?.trim();

    if (newNoteText) {
      const newNote = {
        body: newNoteText,
        addedBy: this.agentId,
        createdAt: new Date().toISOString()
      };

      const ticket = this.tickets.find(t => t._id === ticketId);
      if (ticket) {
        ticket.internalNotes = ticket.internalNotes || [];
        ticket.internalNotes.push(newNote);
        ticket.updatedAt = newNote.createdAt;
      }

      this.toastMessage = "Note added successfully.";
      this.ticketUpdates[ticketId].internalNote = '';
    }

    this.agentService.updateTicketAsAgent(ticketId, {
      status: update.status,
      internalNote: newNoteText || null,
      agentId: this.agentId
    }).subscribe(() => {
      this.toast('✅ Ticket updated');
      this.loadTickets();
      this.loadOverdueCount();
    });
  }

  toast(message: string): void {
    this.toastMessage = message;
    setTimeout(() => this.toastMessage = '', 3000);
  }

  get totalTickets(): number {
    return this.tickets.length;
  }

  get inProgressCount(): number {
    return this.tickets.filter(t => t.status === 'in_progress').length;
  }

  get awaitingCustomerCount(): number {
    return this.tickets.filter(t => t.status === 'waiting_customer').length;
  }

  get slaBreachesCount(): number {
    return this.tickets.filter(t => this.isSlaViolated(t)).length;
  }

  goBack() {
    this.location.back();
  }

  stats = [
    {
      title: 'Total Tickets',
      value: this.totalTickets,
      icon: 'bi bi-card-checklist',
      bg: 'bg-primary'
    },
    {
      title: 'In Progress',
      value: this.inProgressCount,
      icon: 'bi bi-hourglass-split',
      bg: 'bg-success'
    },
    {
      title: 'Awaiting Customer',
      value: this.awaitingCustomerCount,
      icon: 'bi bi-person-exclamation',
      bg: 'bg-warning text-dark'
    },
    {
      title: 'SLA Breaches',
      value: this.slaBreachesCount,
      icon: 'bi bi-clock-history',
      bg: 'bg-danger'
    }
  ];
}
