import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SlaFilterComponent } from './sla-filter.component';

describe('SlaFilterComponent', () => {
  let component: SlaFilterComponent;
  let fixture: ComponentFixture<SlaFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SlaFilterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SlaFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
