import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TicketService } from '../../../services/ticket.service';

@Component({
  selector: 'app-sla-filter',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './sla-filter.component.html'
})
export class SlaFilterComponent implements OnInit {
  slaTickets: any[] = [];
  searchTerm: string = '';

  constructor(private ticketService: TicketService) {}

  ngOnInit(): void {
    this.ticketService.getSLABreaches().subscribe((data: any[]) => {
      this.slaTickets = data;
    });
  }
  calculateOverdue(deadline: string): number {
    const now = new Date();
    const due = new Date(deadline);
    const diffInMs = now.getTime() - due.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    return Math.round(diffInHours * 10) / 10; // rounded to 1 decimal place
  }

  filteredSLABreaches(): any[] {
    return this.slaTickets.filter(ticket =>
      ticket.subject?.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
}
