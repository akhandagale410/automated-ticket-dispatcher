import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TicketDashboardComponent } from '../ticket-dashboard/ticket-dashboard.component';
import { AgentTicketsComponent } from '../agent-tickets/agent-tickets.component';
import { CustomerTicketsComponent } from "../customer-tickets/customer-tickets.component";
import { ProfileManagementComponent } from '../profile-management/profile-management.component';
import { RouterModule } from '@angular/router';
import { NgChartsModule } from 'ng2-charts';
import { EscalationDashboardComponent } from '../escalation-dashboard/escalation-dashboard.component';
import { SlaFilterComponent } from '../sla-filter/sla-filter.component';
import { AgentLoadComponent } from '../agent-load/agent-load.component';
import { CsatTrendComponent } from '../csat-trend/csat-trend.component';
import { LinkedIncidentsComponent } from '../linked-incidents/linked-incidents.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  imports: [CommonModule,NgChartsModule, RouterModule,EscalationDashboardComponent ,SlaFilterComponent ,TicketDashboardComponent, AgentLoadComponent,CsatTrendComponent ,LinkedIncidentsComponent  ,AgentTicketsComponent, CustomerTicketsComponent,ProfileManagementComponent],
})

export class DashboardComponent implements OnInit {
  userRole = localStorage.getItem('role'); // 'admin' | 'agent' | 'customer'

  constructor(private router: Router) {}

  ngOnInit(): void {}

  toggleDarkMode() {
    document.documentElement.classList.toggle('dark');
  }

  isAdmin() {
    return this.userRole === 'admin';
  }

  isAgent() {
    return this.userRole === 'agent';
  }

  isCustomer() {
    return this.userRole === 'customer';
  }
  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }



  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}

