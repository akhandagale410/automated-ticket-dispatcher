import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { TicketService } from '../../../services/ticket.service';

@Component({
  standalone: true,
  selector: 'app-agent-load',
  imports: [CommonModule],
  templateUrl: './agent-load.component.html'
})
export class AgentLoadComponent implements OnInit {
  agents: any[] = [];
  maxTickets = 10;

  constructor(private ticketService: TicketService ,private cdRef: ChangeDetectorRef) {}

  ngOnInit() {
    this.ticketService.getAgentLoad().subscribe({
      next: (data) => {
        this.agents = data;
        console.log('✅ Agent workload loaded:', this.agents);

        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('Error fetching agent workload:', err);
      }
    });
  }
}
