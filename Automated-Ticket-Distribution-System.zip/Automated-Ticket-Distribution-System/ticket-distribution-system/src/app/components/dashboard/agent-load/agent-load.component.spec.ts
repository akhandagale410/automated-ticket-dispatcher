import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentLoadComponent } from './agent-load.component';

describe('AgentLoadComponent', () => {
  let component: AgentLoadComponent;
  let fixture: ComponentFixture<AgentLoadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AgentLoadComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AgentLoadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
