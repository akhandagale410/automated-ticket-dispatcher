import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TicketService } from '../../../services/ticket.service';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'app-linked-incidents',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './linked-incidents.component.html'
})
export class LinkedIncidentsComponent implements OnInit {
  incidentGroups: any[] = [];
  paginatedGroups: any[] = [];
  currentPage: number = 1;
  itemsPerPage: number = 5;
  dataLoaded: boolean = false;
  constructor(private ticketService: TicketService,private cdRef: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.ticketService.getLinkedIncidents().subscribe({
      next: (data) => {
        console.log('✅ Linked incidents loaded:', data);
        this.incidentGroups = data;
        this.dataLoaded = true;
        this.cdRef.detectChanges();
      },
      error: (err) => {
        console.error('❌ Error loading linked incidents:', err);
        this.dataLoaded = true;
      }
    });
  }

}
