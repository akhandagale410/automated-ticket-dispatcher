import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkedIncidentsComponent } from './linked-incidents.component';

describe('LinkedIncidentsComponent', () => {
  let component: LinkedIncidentsComponent;
  let fixture: ComponentFixture<LinkedIncidentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LinkedIncidentsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LinkedIncidentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
