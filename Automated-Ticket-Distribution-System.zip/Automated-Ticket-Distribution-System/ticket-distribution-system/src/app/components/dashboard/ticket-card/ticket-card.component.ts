import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ticket-card',
  standalone: true, // ✅ Required for standalone use
  imports: [CommonModule, FormsModule], // ✅ Needed for ngModel etc.
  templateUrl: './ticket-card.component.html',
  styleUrls: ['./ticket-card.component.css']
})
export class TicketCardComponent {
  @Input() ticket: any;
  @Input() agentId: string = '';

  @Output() update = new EventEmitter<{ ticketId: string, status: string, internalNote: string }>();

  selectedStatus: string = '';
  internalNote: string = '';

  emitUpdate() {
    this.update.emit({
      ticketId: this.ticket._id,
      status: this.selectedStatus,
      internalNote: this.internalNote
    });
    this.selectedStatus = '';
    this.internalNote = '';
  }
}
