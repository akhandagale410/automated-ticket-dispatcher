import { Component, inject, OnInit } from '@angular/core';
import { TicketService } from '../../../services/ticket.service';
import { AuthService } from '../../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-ticket-dashboard',
  standalone: true,
  templateUrl: './ticket-dashboard.component.html',
  styleUrls: ['./ticket-dashboard.component.css'],
  imports: [CommonModule],
})
export class TicketDashboardComponent implements OnInit {
  private ticketService = inject(TicketService);
  private authService = inject(AuthService);
  tickets: any[] = [];
  userRole: string = '';

  ngOnInit(): void {
    this.userRole = this.authService.getRole();
    this.ticketService.getTickets().subscribe((res) => {
      this.tickets = res;
    });
  }

  updateStatus(id: string, status: string) {
    this.ticketService.updateTicket(id, { status }).subscribe();
  }

  escalate(id: string) {
    const reason = prompt('Enter escalation reason:');
    if (reason) {
      this.ticketService.escalateTicket(id, reason).subscribe();
    }
  }
}
