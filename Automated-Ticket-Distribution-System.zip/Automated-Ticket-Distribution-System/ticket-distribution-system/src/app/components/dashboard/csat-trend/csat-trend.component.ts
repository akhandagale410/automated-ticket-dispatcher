import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart } from 'chart.js';
import { TicketService } from '../../../services/ticket.service';


@Component({
  standalone: true,
  selector: 'app-csat-trend',
  imports: [CommonModule],
  templateUrl: './csat-trend.component.html'
})
export class CsatTrendComponent implements OnInit {
  constructor(private ticketService: TicketService) {}

  ngOnInit() {
    this.ticketService.getCSATStats().subscribe(data => {
      this.renderChart(data);
    });
  }

  renderChart(data: any[]) {
    new Chart('csatChart', {
      type: 'line',
      data: {
        labels: data.map(d => d.date),
        datasets: [{
          label: 'CSAT Score',
          data: data.map(d => d.score),
          borderColor: 'green'
        }]
      }
    });
  }
}
