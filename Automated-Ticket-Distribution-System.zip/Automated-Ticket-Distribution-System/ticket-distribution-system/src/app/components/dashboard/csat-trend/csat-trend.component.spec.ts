import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CsatTrendComponent } from './csat-trend.component';

describe('CsatTrendComponent', () => {
  let component: CsatTrendComponent;
  let fixture: ComponentFixture<CsatTrendComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CsatTrendComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CsatTrendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
