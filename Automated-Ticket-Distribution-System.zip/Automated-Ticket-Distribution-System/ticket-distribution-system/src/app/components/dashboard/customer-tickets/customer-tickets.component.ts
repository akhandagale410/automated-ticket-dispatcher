import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CustomerService } from '../../../services/customer.service';
import { TicketService } from '../../../services/ticket.service';
import { RouterModule } from '@angular/router';
import { AgentService } from '../../../services/agent.service';
declare var bootstrap: any;

@Component({
  selector: 'app-customer-tickets',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './customer-tickets.component.html',
  styleUrls: ['./customer-tickets.component.css']
})
export class CustomerTicketsComponent implements OnInit {
  tickets: any[] = [];
  isSubmitting = false;

  filteredTickets: any[] = [];
  customerId = localStorage.getItem('userId') || '';
  selectedTicketId = '';
  selectedTicket: any = null;
  fileAttachments: File[] = [];
  modalInstance: any;
  toastMessage = '';
  agents: any[] = [];
  // Modal control
  isEditing = false;

  @ViewChild('ticketModal') ticketModal!: ElementRef;
  @ViewChild('ticketViewModal') ticketViewModal!: ElementRef;

  filters = { search: '', status: '' };

  newTicket: any = {
    subject: '',
    description: '',
    priority: 'medium',
    category: '',
    domain: '',
    type: 'incident',
    severity: 'minor',
    complexity: 'moderate',
    region: '',
    country: '',
    product: '',
    account: '',
    customerId: this.customerId
  };
  ticketUpdates: { [id: string]: { internalNote: string } } = {};

  summary = {
    new: 0,
    in_progress: 0,
    waiting_customer: 0,
    resolved: 0
  };

  // Pagination
  currentPage = 1;
  pageSize = 5;
totalPages: any;

  get paginatedTickets() {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredTickets.slice(start, start + this.pageSize);
  }

  constructor(
    private customerService: CustomerService,
    private ticketService: TicketService,
    private http: HttpClient,
     private agentService: AgentService
  ) {}

  ngOnInit(): void {

  this.loadAgents();
    this.loadTickets();

  }
  deleteTicket(ticketId: string): void {
    if (confirm('Are you sure you want to delete this ticket?')) {
      this.ticketService.deleteTicket(ticketId).subscribe({
        next: () => {
          // Remove deleted ticket from list
          this.tickets = this.tickets.filter(t => t._id !== ticketId);
          this.loadTickets();
        },
        error: err => {
          console.error('Error deleting ticket:', err);
          alert('Failed to delete the ticket.');
        }
      });
    }
  }

  loadTickets(): void {
    this.customerService.getCustomerTickets(this.customerId).subscribe({
      next: (res) => {
        this.tickets = res.filter(t => t.customerId === this.customerId);
        this.applyFilters();
        this.calculateSummary();
      },
      error: (err) => console.error('Error loading tickets', err)
    });
  }
  ensureTicketUpdateEntry(ticketId: string): boolean {
    if (!this.ticketUpdates[ticketId]) {
      this.ticketUpdates[ticketId] = { internalNote: '' };
    }
    return true;
  }

  addInternalNote(ticketId: string): void {
    const update = this.ticketUpdates[ticketId];
    const newNoteText = update?.internalNote?.trim();

    if (newNoteText) {
      const newNote = {
        body: newNoteText,
        addedBy: this.customerId, // this.agentId should be set from login/session
        createdAt: new Date().toISOString()
      };

      this.ticketService.addInternalNote(ticketId, newNote).subscribe({
        next: (updatedTicket) => {
          const ticket = this.tickets.find(t => t._id === ticketId);
          if (ticket) {
            ticket.internalNotes = updatedTicket.internalNotes; // update from backend
          }
          this.ticketUpdates[ticketId].internalNote = '';
          this.loadTickets();
          this.toastMessage = 'Note added successfully.';
        },
        error: (err) => {
          console.error('Failed to add note', err);
        }
      });
    }
  }
  prepareTicketUpdates(): void {
    this.ticketUpdates = {};
    for (const ticket of this.tickets) {
      this.ticketUpdates[ticket._id] = {
        internalNote: ''
      };
    }
  }
  submitInternalNote(ticketId: string): void {
    const noteText = this.ticketUpdates[ticketId]?.internalNote?.trim();
    if (!noteText) return;

    const newNote = {
      body: noteText,
      addedBy: this.customerId, // or current user id
      createdAt: new Date().toISOString()
    };

    // You can push to ticket object locally if needed
    const ticket = this.tickets.find(t => t._id === ticketId);
    if (ticket) {
      ticket.internalNotes = ticket.internalNotes || [];
      ticket.internalNotes.push(newNote);
    }

    this.ticketService.addInternalNote(ticketId, newNote).subscribe(() => {
      this.toastMessage = '✅ Note added';
      this.ticketUpdates[ticketId].internalNote = '';
    });
  }

  loadAgents(): void {
    this.agentService.getAgents().subscribe({
      next: (res) => {
        this.agents = res;
      },
      error: (err) => console.error('❌ Failed to load agents:', err)
    });
  }

  getAgentName(agentId: string): string {
    const agent = this.agents.find(a => a._id === agentId || a.userId?._id === agentId);
    return agent?.userId ? `${agent.userId.firstName} ${agent.userId.lastName}` : 'Unassigned';
  }
  applyFilters(): void {
    this.filteredTickets = this.tickets.filter(ticket => {
      const searchMatch = this.filters.search
        ? ticket.subject?.toLowerCase().includes(this.filters.search.toLowerCase()) ||
          ticket.category?.toLowerCase().includes(this.filters.search.toLowerCase())
        : true;

      const statusMatch = this.filters.status
        ? ticket.status === this.filters.status
        : true;

      return searchMatch && statusMatch;
    });
    this.currentPage = 1;
  }

  getSummary(status: string): number {
    return this.tickets.filter(t => t.status === status).length;
  }

  calculateSummary(): void {
    this.summary.new = this.getSummary('new');
    this.summary.in_progress = this.getSummary('in_progress');
    this.summary.waiting_customer = this.getSummary('waiting_customer');
    this.summary.resolved = this.getSummary('resolved');
  }
  closeAllModals(): void {
    const openModals = document.querySelectorAll('.modal.show');
    openModals.forEach((modal: any) => {
      const instance = bootstrap.Modal.getInstance(modal);
      if (instance) instance.hide();
    });
  }
  toggleModal(ticket: any = null): void {
    this.closeAllModals();
    this.isEditing = !!ticket;
    console.log('Editing:', this.isEditing);
    if (ticket) {
      this.selectedTicketId = ticket._id;
      this.newTicket = { ...ticket };
    } else {
      this.resetForm();
    }
    this.modalInstance = new bootstrap.Modal(this.ticketModal.nativeElement);
    this.modalInstance.show();
  }



  handleFileInput(event: any): void {
    this.fileAttachments = Array.from(event.target.files);
  }

  submitTicket(): void {
    this.isSubmitting = true;
    const formData = new FormData();
    Object.keys(this.newTicket).forEach(key => {
      if (this.newTicket[key] !== undefined) {
        formData.append(key, this.newTicket[key]);
      }
    });
    this.fileAttachments.forEach(file => formData.append('files', file));

    if (this.isEditing) {
      this.ticketService.updateTicket(this.selectedTicketId, this.newTicket).subscribe({
        next: () => {
          this.toast('✅ Ticket updated');
          this.loadTickets();
          this.closeModal();
          this.isSubmitting = false;
        },
        error: err => {
          this.toast('❌ Error updating ticket');
          this.isSubmitting = false;
        }
      });
    } else {
      this.ticketService.createTicket(this.newTicket).subscribe({
        next: (res: any) => {
          if (this.fileAttachments.length) {
            this.ticketService.attachFiles(res._id, this.fileAttachments).subscribe(() => {
              this.toast('✅ Ticket created with files');
              this.loadTickets();
              this.closeModal();
              this.isSubmitting = false;
            });
          } else {
            this.toast('✅ Ticket created');
            this.loadTickets();
            this.closeModal();
            this.isSubmitting = false;
          }
        },
        error: () => {
          this.toast('❌ Error creating ticket');
          this.isSubmitting = false;
        }
      });
    }
  }

  closeModal(): void {
    if (this.modalInstance) {
      this.modalInstance.hide();
      setTimeout(() => {
        document.body.classList.remove('modal-open');
        document.querySelectorAll('.modal-backdrop')?.forEach(b => b.remove());
      }, 300); // delay ensures Bootstrap animation completes
    }
    this.resetForm();
  }
  openViewModal(ticket: any): void {
    this.closeAllModals();
    this.selectedTicket = ticket;
    const modal = new bootstrap.Modal(document.getElementById('ticketViewModal')!);
    modal.show();
  }
  resetForm(): void {
    this.newTicket = {
      subject: '',
      description: '',
      priority: 'medium',
      category: '',
      domain: '',
      type: 'incident',
      severity: 'minor',
      complexity: 'moderate',
      region: '',
      country: '',
      product: '',
      account: '',
      customerId: this.customerId
    };
    this.fileAttachments = [];
  }

  toast(message: string): void {
    this.toastMessage = message;
    setTimeout(() => this.toastMessage = '', 3000);
  }

  nextPage(): void {
    if ((this.currentPage * this.pageSize) < this.filteredTickets.length) {
      this.currentPage++;
    }
  }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  promptEscalation(ticketId: string) {
    const reason = prompt("Please enter the reason for escalation:");
    if (reason?.trim()) {
      this.ticketService.escalateTicket(ticketId, reason).subscribe({
        next: () => {
          alert("🚨 Ticket escalated successfully!");
          this.loadTickets();
        },
        error: err => {
          console.error("Error escalating ticket", err);
          alert("❌ Failed to escalate the ticket.");
        }
      });
    }
  }
  rateTicket(ticketId: string, rating: number) {
    this.ticketService.submitFeedback(ticketId, rating).subscribe({
      next: () => {
        this.loadTickets(); // reload the ticket list
      },
      error: err => {
        alert(err.error?.error || 'Failed to submit feedback');
      }
    });
  }

}
