import { Component } from '@angular/core';
import { UserProfile,AuthService } from '../../../services/auth.service';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-profile-management',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterModule],
  templateUrl: './profile-management.component.html',
  styleUrl: './profile-management.component.css'
})
export class ProfileManagementComponent {
  profile: UserProfile = {
    _id: '',
    firstName: '',
    lastName: '',
    email: '',
    role: ''
  };

  successMessage = '';
  errorMessage = '';

  constructor(
    private userService: AuthService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const userId = localStorage.getItem('userId'); // 🔑 or get from token
    if (userId) {
      this.userService.getUser(userId).subscribe({
        next: (user) => this.profile = user,
        error: (err) => this.errorMessage = 'Failed to load profile.'
      });
    }
  }

  updateProfile(): void {
    this.userService.updateUser(this.profile._id, this.profile).subscribe({
      next: (res) => {
        this.successMessage = 'Profile updated successfully.';
        this.errorMessage = '';
      },
      error: (err) => {
        this.errorMessage = 'Update failed.';
        this.successMessage = '';
      }
    });
  }
}
