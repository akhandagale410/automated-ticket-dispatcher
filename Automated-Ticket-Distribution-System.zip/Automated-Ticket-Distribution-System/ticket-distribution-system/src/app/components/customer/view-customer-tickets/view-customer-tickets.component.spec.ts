import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomerTicketsComponent } from './view-customer-tickets.component';

describe('ViewCustomerTicketsComponent', () => {
  let component: ViewCustomerTicketsComponent;
  let fixture: ComponentFixture<ViewCustomerTicketsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewCustomerTicketsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewCustomerTicketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
