import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TicketService } from '../../../services/ticket.service';
import { CustomerService } from '../../../services/customer.service';
import { AuthService } from '../../../services/auth.service';
import { Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as XLSX from 'xlsx';
import * as FileSaver from 'file-saver';
import { HttpClient } from '@angular/common/http';
@Component({
  standalone: true,
  selector: 'app-view-customer-tickets',
  imports: [CommonModule,FormsModule],
  templateUrl: './view-customer-tickets.component.html'
})
export class ViewCustomerTicketsComponent implements OnInit {
  tickets: any[] = [];
  customerId: string = '';
  customerName: string = '';

  paginatedTickets: any[] = [];
  currentPage: number = 1;
  pageSize: number = 10;
  totalPages: number = 1;
  totalPagesArray: number[] = [];
  selectedStatus: string = '';
selectedPriority: string = '';

filteredTickets: any[] = [];

uniqueStatuses: string[] = [];
uniquePriorities: string[] = [];

  constructor(
    private route: ActivatedRoute,
    private customerService: CustomerService,
    private authService: AuthService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.customerId = this.route.snapshot.params['id'];
    console.log('Customer ID:', this.customerId);

    this.loadCustomerDetails();
    this.loadCustomerTickets();
  }


  loadCustomerDetails(): void {
    this.authService.getUser(this.customerId).subscribe({
      next: (res) => {
        this.customerName = `${res.firstName} ${res.lastName}`;
        console.log('Customer Name:', this.customerName);
      },
      error: (err) => {
        console.error('Error fetching customer info:', err);
      }
    });
  }

  loadCustomerTickets(): void {
    this.customerService.getCustomerTickets(this.customerId).subscribe({
      next: (res) => {
        this.tickets = res;
        this.totalPages = Math.ceil(this.tickets.length / this.pageSize);
        this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
        this.uniqueStatuses = [...new Set(this.tickets.map(t => t.status))];
        this.uniquePriorities = [...new Set(this.tickets.map(t => t.priority))];
        this.filteredTickets = [...this.tickets];
        this.applyFilters();
        this.paginate();
      },
      error: (err) => console.error('Error fetching tickets:', err)
    });
  }
  applyFilters(): void {
    console.log('Applying filters:', this.selectedStatus, this.selectedPriority);

    this.filteredTickets = this.tickets.filter(ticket => {
      return (
        (!this.selectedStatus || ticket.status === this.selectedStatus) &&
        (!this.selectedPriority || ticket.priority === this.selectedPriority)
      );
    });

    this.totalPages = Math.ceil(this.filteredTickets.length / this.pageSize);
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
    this.currentPage = 1;

    this.paginate(); // paginate from filteredTickets, not full tickets
  }

  changePage(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
    this.paginate();
  }

  paginate(): void {
    const start = (this.currentPage - 1) * this.pageSize;
  const end = start + this.pageSize;
  this.paginatedTickets = this.filteredTickets.slice(start, end);
  }
  goBack(): void {
    this.location.back();
  }

  exportAsExcel(): void {
    const dataToExport = this.filteredTickets.map(ticket => ({
      Subject: ticket.subject,
      Category: ticket.category,
      Product: ticket.product,
      Status: ticket.status,
      Priority: ticket.priority,
      Severity: ticket.severity,
      Complexity: ticket.complexity,
      Rating: ticket.feedbackRating !== undefined ? ticket.feedbackRating : '–',
      Created: new Date(ticket.createdAt).toLocaleString()
    }));

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook: XLSX.WorkBook = { Sheets: { 'Tickets': worksheet }, SheetNames: ['Tickets'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

    const fileName = `Tickets_${this.customerName.replace(/\s+/g, '_')}.xlsx`;
    const data: Blob = new Blob([excelBuffer], { type: 'application/octet-stream' });
    FileSaver.saveAs(data, fileName);
  }
}
