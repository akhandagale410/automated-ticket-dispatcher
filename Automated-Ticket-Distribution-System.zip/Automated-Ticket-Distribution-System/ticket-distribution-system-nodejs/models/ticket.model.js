const mongoose = require('mongoose');

const TicketSchema = new mongoose.Schema({
  subject: { type: String, required: true },
  description: { type: String, required: true },

  category: { type: String },
  domain: { type: String },
  product: { type: String },
  operationType: { type: String },
  priority: { type: String, enum: ['low', 'medium', 'high', 'critical'], default: 'medium' },
  complexity: { type: String, enum: ['simple', 'moderate', 'complex'], default: 'moderate' },
  severity: { type: String, enum: ['minor', 'major', 'critical', 'blocker'], default: 'minor' },
  type: { type: String, enum: ['incident', 'request', 'problem', 'change'], default: 'incident' },

  region: { type: String },
  country: { type: String },
  account: { type: String },
  skillRequired: [String],
  tags: [String],
  securityRestriction: { type: Boolean, default: false },

  status: {
    type: String,
    enum: ['new', 'assigned', 'in_progress', 'waiting_customer', 'resolved', 'closed'],
    default: 'new'
  },

  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Agent', default: null },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  slaDeadline: { type: Date },

  escalated: { type: Boolean, default: false },
  escalationReason: String,

  feedbackRating: { type: Number, min: 1, max: 5 },
  internalNotes: [{ body: String, addedBy: String, createdAt: Date }],
  feedbackDate: { type: Date },
  attachments: [String],
  history: [{
    status: String,
    changedAt: Date,
    changedBy: String
  }]
});

// Middleware to update updatedAt
TicketSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Ticket', TicketSchema);
