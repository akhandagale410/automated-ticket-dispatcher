// models/agent.model.js

const mongoose = require('mongoose');

const AgentSchema = new mongoose.Schema({
  // Link to user credentials
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true // One user = one agent profile
  },

  // Skill and profile metadata
  skills: [String], // e.g., ['network', 'login issue', 'database']
  domainExpertise: [String], // e.g., ['cloud', 'security']
  experience: {
    type: Number,
    default: 0 // years of experience
  },
  certifications: [String],

  // Workload tracking
  maxTickets: {
    type: Number,
    default: 5
  },
  workload: {
    type: Number,
    default: 0 // number of active tickets
  },
  availability: {
    type: String,
    enum: ['online', 'offline', 'busy'],
    default: 'offline'
  },

  // Historical ticket resolution info
  ticketHistory: [
    {
      ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket' },
      subject: String,
      category: String,
      complexity: String,
      resolvedAt: Date,
      resolutionTime: Number, // in minutes
      customerSatisfaction: Number // rating 1–5
    }
  ],

  // Aggregated performance stats
  totalTicketsResolved: {
    type: Number,
    default: 0
  },
  avgResolutionTime: {
    type: Number,
    default: 0 // in minutes
  },
  avgCustomerRating: {
    type: Number,
    default: 0 // 1 to 5
  },

  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Agent', AgentSchema);

