const mongoose = require('mongoose');
const MONGO_URI = 'mongodb://localhost:27017/Automated-Ticket-Distribution-System';

const customerId = new mongoose.Types.ObjectId("6802434f6537a0b25add9c11");
const agentId = new mongoose.Types.ObjectId("6803c978e5087b4f3a8a194b");

async function run() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("✅ Connected to MongoDB");

    const Ticket = require('./models/ticket.model'); // Adjust the path
    const Agent = require('./models/agent.model');

    const dummyTickets = [
        {
          subject: "Global search filter not returning expected contacts",
          description: "Using search filters by department or location returns no results, even for known entries.",
          category: "Contact Search",
          domain: "UC",
          product: "AADS",
          operationType: "Support",
          priority: "medium",
          complexity: "moderate",
          severity: "minor",
          type: "incident",
          skillRequired: ["AADS", "Directory Search"],
          tags: ["filter", "contact search", "directory", "AADS"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 4,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Contact directory lookup fails for newly added users",
          description: "Newly onboarded users are not appearing in AADS contact search results until next day.",
          category: "Directory Sync",
          domain: "UC",
          product: "AADS",
          operationType: "Support",
          priority: "medium",
          complexity: "moderate",
          severity: "minor",
          type: "problem",
          skillRequired: ["LDAP", "AADS"],
          tags: ["contact", "directory", "sync delay"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 3,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Advanced search filter in AADS fails to load options",
          description: "Dropdown filter fields like department and region are not being populated in the contact search UI.",
          category: "UI Issue",
          domain: "Applications",
          product: "AADS",
          operationType: "Support",
          priority: "low",
          complexity: "simple",
          severity: "minor",
          type: "incident",
          skillRequired: ["AADS", "UI"],
          tags: ["search filter", "dropdown", "AADS UI"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 3,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "LDAP search filter logic mismatch",
          description: "Custom LDAP search filter using (&(objectClass=user)(|(dept=IT)(region=APAC))) not returning expected users.",
          category: "LDAP",
          domain: "Security",
          product: "AADS",
          operationType: "Integration",
          priority: "high",
          complexity: "complex",
          severity: "major",
          type: "problem",
          skillRequired: ["LDAP Filters", "AADS"],
          tags: ["LDAP", "filter logic", "AADS", "integration"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 4,
          escalated: true,
          escalationReason: "Critical filters blocked user sync",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Manual backup in AADS returns permission error",
          description: "Users with admin role unable to initiate manual backup. Error: 'access denied to backup script'.",
          category: "Backup",
          domain: "Infrastructure",
          product: "AADS",
          operationType: "Support",
          priority: "medium",
          complexity: "moderate",
          severity: "minor",
          type: "incident",
          skillRequired: ["AADS", "Linux Permissions"],
          tags: ["manual backup", "permissions", "AADS"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 3,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Scheduled backup not created since last patch",
          description: "AADS has not generated any scheduled backup files since patch SP6 was applied last week.",
          category: "Backup",
          domain: "Infrastructure",
          product: "AADS",
          operationType: "Maintenance",
          priority: "high",
          complexity: "complex",
          severity: "major",
          type: "problem",
          skillRequired: ["Backup Scripts", "AADS"],
          tags: ["backup", "schedule", "patch", "cron"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 4,
          escalated: true,
          escalationReason: "Disaster recovery plan risk",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Contact search returns stale profile photos",
          description: "User contact images in the search results haven't updated despite new directory uploads.",
          category: "Contact Search",
          domain: "Applications",
          product: "AADS",
          operationType: "Support",
          priority: "low",
          complexity: "simple",
          severity: "minor",
          type: "incident",
          skillRequired: ["AADS", "Directory Caching"],
          tags: ["AADS", "image", "stale data", "profile photo"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 3,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Filtered user search fails on special characters",
          description: "Searching with names that include special characters like é or ö fails to return any results.",
          category: "Search",
          domain: "UC",
          product: "AADS",
          operationType: "Support",
          priority: "medium",
          complexity: "moderate",
          severity: "minor",
          type: "problem",
          skillRequired: ["Encoding", "AADS"],
          tags: ["search", "unicode", "AADS"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 4,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "AADS backup files not rotated, storage full",
          description: "Old backup archives are not getting cleaned up. Backup folder has consumed 95% disk.",
          category: "Backup",
          domain: "Infrastructure",
          product: "AADS",
          operationType: "Monitoring",
          priority: "high",
          complexity: "moderate",
          severity: "major",
          type: "incident",
          skillRequired: ["AADS", "Retention Policy"],
          tags: ["backup", "storage", "retention", "disk full"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 5,
          escalated: true,
          escalationReason: "System nearing outage due to storage",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Filter by department fails in contact search",
          description: "Search by department returns inconsistent results across browsers. Working in Edge, broken in Chrome.",
          category: "Search",
          domain: "Applications",
          product: "AADS",
          operationType: "UI Support",
          priority: "low",
          complexity: "simple",
          severity: "minor",
          type: "incident",
          skillRequired: ["UI Testing", "Directory Search"],
          tags: ["browser", "department filter", "contact search"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 3,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "LDAP sync skipped due to max entry threshold",
          description: "LDAP job did not run because previous sync returned too many entries. Needs split or paging config.",
          category: "LDAP",
          domain: "Security",
          product: "AADS",
          operationType: "Integration",
          priority: "high",
          complexity: "complex",
          severity: "major",
          type: "problem",
          skillRequired: ["LDAP", "Paging", "AADS"],
          tags: ["LDAP sync", "entry threshold", "paging"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 4,
          escalated: true,
          escalationReason: "Critical sync blocked for large OU",
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          subject: "Contact search slow after directory bulk update",
          description: "Contact search performance degraded after bulk update of AD users. Queries now take 5+ seconds.",
          category: "Performance",
          domain: "UC",
          product: "AADS",
          operationType: "Support",
          priority: "medium",
          complexity: "moderate",
          severity: "minor",
          type: "problem",
          skillRequired: ["AADS", "Search Optimization"],
          tags: ["performance", "contact search", "directory"],
          status: "resolved",
          customerId,
          assignedTo: agentId,
          feedbackRating: 4,
          escalated: false,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ]
      
      
      
      
      
      
    const inserted = await Ticket.insertMany(dummyTickets);
    console.log(`✅ Inserted ${inserted.length} tickets.`);

    const ticketHistory = inserted.map((ticket, i) => ({
      ticketId: ticket._id,
      subject: ticket.subject,
      category: ticket.category,
      complexity: ticket.complexity,
      resolvedAt: new Date(),
      resolutionTime: 60 + i * 5,
      customerSatisfaction: ticket.feedbackRating
    }));

    await Agent.updateOne(
      { _id: agentId },
      {
        $set: {
          totalTicketsResolved: ticketHistory.length,
          avgResolutionTime: 67,
          avgCustomerRating: 4.2,
          availability: "online"
        },
        $push: { ticketHistory: { $each: ticketHistory } }
      }
    );

    console.log("✅ Agent ticketHistory updated.");
    process.exit(0);
  } catch (err) {
    console.error("❌ Error:", err);
    process.exit(1);
  }
}

run();
