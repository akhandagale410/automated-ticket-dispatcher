const Agent = require('../models/agent.model');
const User = require('../models/user.model');
const Ticket = require('../models/ticket.model');

// 🔹 Create agent
const createAgent = async (req, res) => {
  try {
    const { userId, skills, experience, certifications, domainExpertise, maxTickets } = req.body;
    const user = await User.findById(userId);
    if (!user || user.role !== 'agent') {
      return res.status(400).json({ error: 'Invalid agent userId or role' });
    }

    const agent = new Agent({ userId, skills, experience, certifications, domainExpertise, maxTickets });
    await agent.save();
    res.status(201).json(agent);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
const getAllAgents = async (req, res) => {
  try {
    // 1️⃣ Get all agent documents with populated user & ticket info
    const existingAgents = await Agent.find()
      .populate({
        path: 'userId',
        match: { role: 'agent' },
        select: 'firstName lastName email role'
      })
      .populate({
        path: 'ticketHistory.ticketId',
        select: 'subject category status createdAt resolvedAt'
      })
      .lean();

    // 2️⃣ Filter out any agent docs where the user wasn't matched
    const filteredAgents = existingAgents.filter(agent => agent.userId !== null);

    // 3️⃣ Get agent users that DO NOT have an Agent document yet
    const agentUserIds = filteredAgents.map(agent => agent.userId._id.toString());
    const unmatchedUsers = await User.find({
      role: 'agent',
      _id: { $nin: agentUserIds }
    }).select('firstName lastName email role').lean();

    // 4️⃣ Convert unmatched users into agent-like objects with blank agent data
    const unmappedAgents = unmatchedUsers.map(user => ({
      userId: user,
      skills: [],
      domainExpertise: [],
      experience: 0,
      certifications: [],
      maxTickets: 5,
      workload: 0,
      availability: 'offline',
      ticketHistory: [],
      totalTicketsResolved: 0,
      avgResolutionTime: 0,
      avgCustomerRating: 0,
      createdAt: user.createdAt || new Date()
    }));

    // 5️⃣ Combine both: agents with Agent doc + users without Agent doc
    const allAgents = [...filteredAgents, ...unmappedAgents];

    res.status(200).json(allAgents);
  } catch (error) {
    console.error('Error fetching all agent data:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

// // 🔹 Get all agents
// const getAllAgents = async (req, res) => {
//   try {
//     const { availability, skill } = req.query;
//     const query = {};
//     if (availability) query.availability = availability;
//     if (skill) query.skills = { $in: [skill] };

//     const agents = await Agent.find(query).populate('userId', 'firstName lastName email role');
//     res.json(agents);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };

// 🔹 Get agent by ID
const getAgentById = async (req, res) => {
  try {
    const agent = await Agent.findOne({ userId: req.params.id })
      .populate({
        path: 'userId',
        match: { role: 'agent' },
        select: 'firstName lastName email role'
      });

    if (!agent || !agent.userId) {
      return res.status(404).json({ error: 'Agent not found or user role mismatch' });
    }

    res.json(agent);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};



// 🔹 Update agent
const updateAgent = async (req, res) => {
  try {
    const agent = await Agent.findById(req.params.id);
    if (!agent) return res.status(404).json({ error: 'Agent not found' });

    Object.assign(agent, req.body);
    await agent.save();
    res.json(agent);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 🔹 Log resolution
const logTicketResolution = async (req, res) => {
  try {
    const { ticketId, resolutionTime, customerSatisfaction } = req.body;
    const agent = await Agent.findById(req.params.id);
    const ticket = await Ticket.findById(ticketId);

    if (!agent || !ticket) {
      return res.status(404).json({ error: 'Agent or Ticket not found' });
    }

    agent.ticketHistory.push({
      ticketId,
      subject: ticket.subject,
      category: ticket.category,
      complexity: ticket.complexity,
      resolvedAt: new Date(),
      resolutionTime,
      customerSatisfaction
    });

    agent.totalTicketsResolved += 1;
    agent.workload = Math.max(agent.workload - 1, 0);

    const totalTime = agent.ticketHistory.reduce((acc, t) => acc + (t.resolutionTime || 0), 0);
    const totalRating = agent.ticketHistory.reduce((acc, t) => acc + (t.customerSatisfaction || 0), 0);

    agent.avgResolutionTime = totalTime / agent.ticketHistory.length;
    agent.avgCustomerRating = totalRating / agent.ticketHistory.length;

    await agent.save();
    res.json({ message: 'Resolution logged', agent });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 🔹 Agent updates ticket
const agentUpdateTicket = async (req, res) => {
  try {
    const { status, internalNote, agentId } = req.body;
    const ticket = await Ticket.findById(req.params.id);

    if (!ticket || String(ticket.assignedTo) !== agentId) {
      return res.status(403).json({ message: 'Access denied or ticket not found' });
    }

    if (status) {
      ticket.status = status;
      ticket.history.push({
        status,
        changedAt: new Date(),
        changedBy: agentId
      });
    }

    if (internalNote) {
      ticket.internalNotes = ticket.internalNotes || [];
      ticket.internalNotes.push({
        body: internalNote,
        addedBy: agentId,
        createdAt: new Date()
      });
    }

    await ticket.save();
    res.json(ticket);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 🔹 Assigned tickets
const getTicketsAssignedToAgent = async (req, res) => {
  try {
    // Step 1: Find agent by userId (req.params.id)
    const agent = await Agent.findOne({ userId: req.params.id });
  
    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    // Step 2: Find tickets assigned to this agent
    const tickets = await Ticket.find({ assignedTo: agent._id }).sort({ createdAt: -1 });
    
    res.json(tickets);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/agents/full-create
const createAgentWithUser = async (req, res) => {
  try {
    const {
      firstName, lastName, email, password,
      skills, domainExpertise, experience,
      certifications, maxTickets
    } = req.body;

    // Check if user already exists
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'User already exists with this email' });

    // Create User with agent role
    const user = new User({ firstName, lastName, email, password, role: 'agent' });
    await user.save();

    // Create Agent Profile
    const agent = new Agent({
      userId: user._id,
      skills,
      domainExpertise,
      experience,
      certifications,
      maxTickets
    });

    await agent.save();

    res.status(201).json({ user, agent });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
const updateAgentWithUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const {
      firstName,
      lastName,
      email,
      skills,
      domainExpertise,
      experience,
      certifications,
      maxTickets,
      availability
    } = req.body;

    // 🔄 Update user info
    const user = await User.findByIdAndUpdate(
      userId,
      { firstName, lastName, email },
      { new: true }
    );

    if (!user) return res.status(404).json({ message: 'User not found' });

    // 🛠️ Upsert agent info (create if doesn't exist)
    const agent = await Agent.findOneAndUpdate(
      { userId },
      {
        $set: {
          skills,
          domainExpertise,
          experience,
          certifications,
          maxTickets,
          availability
        }
      },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );

    res.status(200).json({ user, agent });
  } catch (err) {
    console.error('Error updating agent:', err);
    res.status(500).json({ error: err.message });
  }


};
const deleteAgent = async (req, res) => {
  const agentId = req.params.id;
//console.log('Deleting agent with ID:', agentId);
  try {
    const agent = await Agent.findById(agentId);
    if (!agent) {
      return res.status(404).json({ message: 'Agent not found' });
    }

    // First delete the associated user if needed
    await User.findByIdAndDelete(agent.userId);

    // Then delete the agent profile
    await Agent.findByIdAndDelete(agentId);

    res.status(200).json({ message: 'Agent and associated user deleted successfully' });
  } catch (error) {
    console.error('Error deleting agent:', error);
    res.status(500).json({ message: 'Failed to delete agent', error });
  }
};
// ✅ Export all
module.exports = {
  createAgent,
  getAllAgents,
  getAgentById,
  updateAgent,
  logTicketResolution,
  getTicketsAssignedToAgent,
  agentUpdateTicket,
  createAgentWithUser,
  updateAgentWithUser,
  deleteAgent
};
