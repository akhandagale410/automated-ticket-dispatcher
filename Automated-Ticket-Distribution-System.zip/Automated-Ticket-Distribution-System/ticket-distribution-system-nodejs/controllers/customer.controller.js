const User = require('../models/user.model');
const Ticket = require('../models/ticket.model');

// 🔹 Get all customers
const getAllCustomers = async (req, res) => {
  try {
    const customers = await User.find({ role: 'customer' }).select('-password');
    res.status(200).json(customers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 🔹 Create new customer
const createCustomer = async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'Email already registered' });

    const newCustomer = new User({ firstName, lastName, email, password, role: 'customer' });
    await newCustomer.save();

    res.status(201).json({ message: 'Customer created', customer: newCustomer });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 🔹 Update customer info
const updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const { firstName, lastName, email } = req.body;

    const customer = await User.findOneAndUpdate(
      { _id: id, role: 'customer' },
      { firstName, lastName, email },
      { new: true }
    );

    if (!customer) return res.status(404).json({ message: 'Customer not found' });

    res.status(200).json({ message: 'Customer updated', customer });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 🔹 Get all tickets created by customer
const getCustomerTickets = async (req, res) => {
  try {
    const customerId = req.params.customerId;
    const tickets = await Ticket.find({ customerId }).sort({ createdAt: -1 });
    res.status(200).json(tickets);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
// ❌ Delete Customer
const deleteCustomer = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await User.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ error: 'Customer not found' });

    res.status(200).json({ message: 'Customer deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete customer' });
  }
};
// 🔹 Customer creates a ticket
const createCustomerTicket = async (req, res) => {
  try {
    const {
      subject,
      description,
      priority,
      category,
      domain,
      product,
      type,
      country,
      region,
      skillRequired,
      securityRestriction,
      customerId
    } = req.body;

    const ticket = new Ticket({
      subject,
      description,
      priority,
      category,
      domain,
      product,
      type,
      country,
      region,
      skillRequired,
      securityRestriction,
      customerId
    });

    await ticket.save();

    // ✅ Return the created ticket directly so frontend gets _id
    res.status(201).json(ticket);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllCustomers,
  createCustomer,
  updateCustomer,
  getCustomerTickets,
  createCustomerTicket,
  deleteCustomer
};
