const Ticket = require('../models/ticket.model');
const axios = require('axios');
const mongoose = require('mongoose');
const Agent = require('../models/agent.model');
const User = require('../models/user.model');
const { calculateSLADeadline } = require('../utils/slaCalculator');

exports.createTicket = async (req, res) => {
  try {
    const {
      subject,
      description,
      priority,
      category,
      domain,
      product,
      type,
      country,
      region,
      skillRequired,
      securityRestriction,
      customerId
    } = req.body;

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return res.status(400).json({ error: 'Invalid customerId format' });
    }

    const ticket = new Ticket({
      subject,
      description,
      priority,
      category,
      domain,
      product,
      type,
      country,
      region,
      skillRequired,
      securityRestriction,
      customerId,
      status: 'new'
    });

    // 🔍 Analyze ticket via NLP engine
    if (subject && description) {
      const { data: analysis } = await axios.post('http://localhost:8000/analyze', {
        subject,
        description
      });

      ticket.complexity = analysis.complexity || 'moderate';
      ticket.category = analysis.category || category || 'General';
      ticket.domain = analysis.domain || domain || 'General';
      ticket.priority = analysis.priority || priority || 'medium';
      ticket.tags = analysis.tags || [];

      // 🕒 Set SLA deadline based on dynamic priority and type
      ticket.slaDeadline = calculateSLADeadline({ type: ticket.type, priority: ticket.priority });

      // 🧠 Assign agent if recommended
      if (analysis.assignedAgentId && mongoose.Types.ObjectId.isValid(analysis.assignedAgentId)) {
        const agent = await Agent.findById(analysis.assignedAgentId);
        if (agent) {
          ticket.assignedTo = agent._id;
          ticket.status = 'assigned';
          agent.workload += 1;
          await agent.save();
        } else {
          console.warn('[WARN] Assigned agent not found');
        }
      } else {
        console.warn('[WARN] No valid assignedAgentId from analysis');
      }
    } else {
      // fallback SLA if no analysis
      ticket.slaDeadline = calculateSLADeadline({ type, priority });
    }

    await ticket.save();
    res.status(201).json(ticket);
  } catch (err) {
    console.error('Ticket creation error:', err);
    res.status(500).json({ error: err.message });
  }
};





// 📌 Get all tickets with filters
exports.getTickets = async (req, res) => {
  const {
    status, priority, region, product, severity, country, account, category,
    page = 1, limit = 10
  } = req.query;

  const filter = {};
  if (status) filter.status = status;
  if (priority) filter.priority = priority;
  if (region) filter.region = region;
  if (product) filter.product = product;
  if (severity) filter.severity = severity;
  if (country) filter.country = country;
  if (account) filter.account = account;
  if (category) filter.category = category;

  try {
    const tickets = await Ticket.find(filter)
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort({ createdAt: -1 });

    const total = await Ticket.countDocuments(filter);
    res.json({ data: tickets, total });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 📌 Get ticket by ID
exports.getTicketById = async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id);
    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });
    res.json(ticket);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 📌 Update ticket
exports.updateTicket = async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id);
    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });

    Object.assign(ticket, req.body);

    if (req.body.status) {
      ticket.history.push({
        status: req.body.status,
        changedAt: new Date(),
        changedBy: req.body.changedBy || 'system'
      });
    }

    await ticket.save();
    res.json(ticket);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};
exports.getEscalatedTickets = async (req, res) => {
  try {
    const tickets = await Ticket.find({ escalated: true }).sort({ createdAt: -1 });
    res.status(200).json(tickets);
  } catch (error) {
    console.error('Error fetching escalated tickets:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
// 📌 Escalate ticket
exports.escalateTicket = async (req, res) => {
  try {
    const ticket = await Ticket.findByIdAndUpdate(
      req.params.id,
      {
        escalated: true,
        escalationReason: req.body.escalationReason
      },
      { new: true }
    );

    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });
    res.json(ticket);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// 📌 SLA Violations
exports.getSLAViolations = async (req, res) => {
  try {
    const now = new Date();
    const violations = await Ticket.find({
      slaDeadline: { $lt: now },
      status: { $nin: ['resolved', 'closed'] }
    });
    res.json(violations);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
// GET /tickets/sla-violations/:agentId

exports.getSlaViolationsForAgent = async (req, res) => {
  try {
    const now = new Date();
    
    // Assuming the route is /agent/sla/:agentId
    const agent = await Agent.findOne({ userId: req.params.agentId });

    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    const violations = await Ticket.find({
      assignedTo: agent._id,
      slaDeadline: { $lt: now },
      status: { $nin: ['resolved', 'closed'] }
    });

    res.status(200).json({ count: violations.length, data: violations });
  } catch (err) {
    console.error('[SLA Agent Check Error]', err);
    res.status(500).json({ error: 'Failed to fetch SLA violations for agent' });
  }
};


// 📌 Attach Files
exports.attachFiles = async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id);
    if (!ticket) return res.status(404).json({ message: 'Ticket not found' });

    const uploadedFiles = req.files.map(file => file.filename);
    ticket.attachments = [...(ticket.attachments || []), ...uploadedFiles];

    await ticket.save();
    res.json({ message: 'Files attached successfully', ticket });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// 📌 Get tickets assigned to a specific agent
exports.getAgentTickets = async (req, res) => {
  try {
    const agentId = req.params.agentId;

    const tickets = await Ticket.find({ assignedTo: agentId }).sort({ createdAt: -1 });

    res.json(tickets);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.agentUpdateTicket = async (req, res) => {
  try {
    const { status, internalNote, agentId } = req.body;

    const ticket = await Ticket.findById(req.params.id);

    if (status) {
      ticket.status = status;
      ticket.history.push({
        status,
        changedAt: new Date(),
        changedBy: agentId
      });
    }

    if (internalNote) {
      ticket.internalNotes.push({
        body: internalNote,
        addedBy: agentId,
        createdAt: new Date()
      });
    }

    await ticket.save();
    res.json(ticket);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
// 📌 Get linked incidents grouped by tag similarity
exports.getLinkedIncidents = async (req, res) => {
  try {
    const pipeline = [
      {
        $match: {
          type: 'incident', // only incident-type tickets
          tags: { $exists: true, $ne: [] }
        }
      },
      {
        $unwind: "$tags" // explode tags to group on
      },
      {
        $group: {
          _id: "$tags", // group by each tag
          tickets: {
            $push: {
              _id: "$_id",
              subject: "$subject",
              description: "$description",
              createdAt: "$createdAt",
              priority: "$priority",
              status: "$status"
            }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 } // sort by number of incidents
      }
    ];

    const result = await Ticket.aggregate(pipeline);
    res.status(200).json(result);
  } catch (err) {
    console.error('[Linked Incident Error]', err);
    res.status(500).json({ error: err.message });
  }
};
// 📊 GET CSAT Trends (last 30 days by default)
exports.getCSATStats = async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const csatStats = await Ticket.aggregate([
      {
        $match: {
          feedbackRating: { $exists: true, $ne: null },
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          score: { $avg: "$feedbackRating" },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    const formatted = csatStats.map(item => ({
      date: item._id,
      score: parseFloat(item.score.toFixed(2)),
      count: item.count
    }));

    res.json(formatted);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.getAgentWorkloadStats = async (req, res) => {
  try {
    const activeStatuses = ['assigned', 'in_progress', 'waiting_customer'];

    // Reset all workloads first
    await Agent.updateMany({}, { workload: 0 });

    // Aggregate workload
    const workloads = await Ticket.aggregate([
      {
        $match: {
          assignedTo: { $ne: null },
          status: { $in: activeStatuses }
        }
      },
      {
        $group: {
          _id: "$assignedTo",
          ticketCount: { $sum: 1 }
        }
      }
    ]);

    // Update each agent with current workload
    for (const { _id: agentId, ticketCount } of workloads) {
      
      await Agent.findByIdAndUpdate(agentId, { workload: ticketCount });
    }

    // Return enriched agent data
    const enrichedStats = await Agent.find()
      .populate('userId', 'firstName lastName')
      .select('workload maxTickets userId')
      .lean();

    const response = enrichedStats.map(agent => ({
      agentId: agent._id,
      name: `${agent.userId?.firstName || ''} ${agent.userId?.lastName || ''}`,
      ticketCount: agent.workload,
      maxTickets: agent.maxTickets
    }));

    res.status(200).json(response);
  } catch (err) {
    console.error('Error fetching/updating agent workloads:', err);
    res.status(500).json({ error: err.message });
  }
};


exports.getAllTicketsForAdmin = async (req, res) => {
  try {
    const tickets = await Ticket.find().populate('assignedTo', 'firstName lastName email').populate('customerId', 'firstName lastName email');
    res.json(tickets);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tickets' });
  }
};

exports.assignTicketManually = async (req, res) => {
  const { ticketId, agentId } = req.body;
  try {
    const updated = await Ticket.findByIdAndUpdate(ticketId, {
      assignedTo: agentId,
      status: 'assigned'
    }, { new: true });

    if (!updated) return res.status(404).json({ error: 'Ticket not found' });
    res.json({ message: 'Ticket assigned successfully', ticket: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to assign ticket' });
  }
};
exports.deleteTicket = async (req, res) => {
  try {
    const ticketId = req.params.id;
    const result = await Ticket.findByIdAndDelete(ticketId);
    
    if (!result) {
      return res.status(404).json({ message: 'Ticket not found' });
    }

    res.status(200).json({ message: 'Ticket deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ message: 'Server error during deletion' });
  }
};
exports.addInternalNote = async (req, res) => {
  const { ticketId } = req.params;
  const { body, addedBy, createdAt } = req.body;

  if (!body || !addedBy || !createdAt) {
    return res.status(400).json({ error: 'Missing required fields: body, addedBy, or createdAt.' });
  }

  try {
    const ticket = await Ticket.findById(ticketId);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found.' });
    }

    // Add the new note
    ticket.internalNotes = ticket.internalNotes || [];
    ticket.internalNotes.push({ body, addedBy, createdAt: new Date(createdAt) });

    ticket.updatedAt = new Date(); // update the updatedAt timestamp
    await ticket.save();

    res.status(200).json({ message: 'Internal note added successfully.', ticket });
  } catch (err) {
    console.error('Error adding internal note:', err);
    res.status(500).json({ error: 'Internal server error.' });
  }
};


exports.submitFeedback = async (req, res) => {
  try {
    const ticketId = req.params.ticketId;
    const customerId = req.user.id; // from token
    const { rating } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Rating must be between 1 and 5' });
    }

    const ticket = await Ticket.findOne({ _id: ticketId, createdBy: customerId });

    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found or not owned by you' });
    }

    if (ticket.status !== 'resolved') {
      return res.status(400).json({ error: 'Feedback allowed only after ticket is resolved' });
    }

    if (ticket.feedbackRating) {
      return res.status(400).json({ error: 'Feedback already submitted for this ticket' });
    }

    ticket.feedbackRating = rating;
    ticket.feedbackDate = new Date();

    await ticket.save();

    res.status(200).json({ message: 'Feedback submitted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
