// utils/slaCalculator.js

/**
 * Calculates SLA deadline based on ticket type and priority.
 * Returns a Date object that represents the SLA deadline.
 *
 * Priority levels: low, medium, high, critical
 * Types: question, incident, problem, request
 */
function calculateSLADeadline({ type = 'request', priority = 'medium' }) {
    const now = new Date();
    let hoursToAdd = 4; // Default fallback
  
    const slaMatrix = {
      question:    { low: 72, medium: 48, high: 24, critical: 12 },
      incident:    { low: 48, medium: 24, high: 12, critical: 4 },
      problem:     { low: 72, medium: 48, high: 24, critical: 8 },
      request:     { low: 96, medium: 72, high: 48, critical: 24 }
    };
  
    const typeEntry = slaMatrix[type.toLowerCase()];
    if (typeEntry) {
      hoursToAdd = typeEntry[priority.toLowerCase()] || hoursToAdd;
    }
  
    return new Date(now.getTime() + hoursToAdd * 60 * 60 * 1000);
  }
  
  module.exports = { calculateSLADeadline };
  