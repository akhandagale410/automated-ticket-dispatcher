const redis = require('redis');

const client = redis.createClient({
  url: 'redis://172.19.21.69:6379'
});

client.on('error', err => {
  console.error('[Redis Error]', err);
});

client.connect();

module.exports = client;
