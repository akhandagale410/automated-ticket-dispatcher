const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/authMiddleware');

const {
  createAgent,
  getAllAgents,
  getAgentById,
  updateAgent,
  logTicketResolution,
  getTicketsAssignedToAgent,
  agentUpdateTicket,
  createAgentWithUser,
  updateAgentWithUser,
  deleteAgent
} = require('../controllers/agent.controller');

/**
 * @swagger
 * tags:
 *   name: Agent
 *   description: Agent management and performance tracking
 */

/**
 * @swagger
 * /api/agents:
 *   get:
 *     summary: Get all agents
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: availability
 *         schema:
 *           type: string
 *           enum: [online, offline, busy]
 *       - in: query
 *         name: skill
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: List of agents
 */
router.get('/', verifyToken, getAllAgents);

/**
 * @swagger
 * /api/agents:
 *   post:
 *     summary: Create a new agent profile
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - userId
 *             properties:
 *               userId:
 *                 type: string
 *               skills:
 *                 type: array
 *                 items:
 *                   type: string
 *               domainExpertise:
 *                 type: array
 *                 items:
 *                   type: string
 *               experience:
 *                 type: number
 *               certifications:
 *                 type: array
 *                 items:
 *                   type: string
 *               maxTickets:
 *                 type: number
 *     responses:
 *       201:
 *         description: Agent profile created
 */
router.post('/', verifyToken, createAgent);

/**
 * @swagger
 * /api/agents/{id}:
 *   get:
 *     summary: Get agent by ID
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Agent object
 *       404:
 *         description: Agent not found
 */
router.get('/:id', verifyToken, getAgentById);

/**
 * @swagger
 * /api/agents/{id}:
 *   patch:
 *     summary: Update agent details
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               availability:
 *                 type: string
 *               skills:
 *                 type: array
 *                 items:
 *                   type: string
 *               workload:
 *                 type: number
 *     responses:
 *       200:
 *         description: Updated agent
 */
router.patch('/:id', verifyToken, updateAgent);

/**
 * @swagger
 * /api/agents/{id}:
 *   delete:
 *     summary: Delete an agent
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Agent deleted
 */
router.delete('/:id', verifyToken, deleteAgent);

/**
 * @swagger
 * /api/agents/{id}/resolve-ticket:
 *   post:
 *     summary: Log a resolved ticket and update agent's performance
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - ticketId
 *               - resolutionTime
 *             properties:
 *               ticketId:
 *                 type: string
 *               resolutionTime:
 *                 type: number
 *               customerSatisfaction:
 *                 type: number
 *     responses:
 *       200:
 *         description: Ticket resolution logged
 */
router.post('/:id/resolve-ticket', verifyToken, logTicketResolution);

/**
 * @swagger
 * /api/agents/{id}/tickets:
 *   get:
 *     summary: Get all tickets assigned to an agent
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: List of assigned tickets
 */
router.get('/:id/tickets', verifyToken, getTicketsAssignedToAgent);

/**
 * @swagger
 * /api/agents/{id}/agent-update:
 *   patch:
 *     summary: Agent-specific ticket update endpoint
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               ticketId:
 *                 type: string
 *               notes:
 *                 type: string
 *               status:
 *                 type: string
 *     responses:
 *       200:
 *         description: Ticket updated by agent
 */
router.patch('/:id/agent-update', verifyToken, agentUpdateTicket);

/**
 * @swagger
 * /api/agents/full-create:
 *   post:
 *     summary: Full agent profile and user account creation
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - password
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *               skills:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Agent and user created successfully
 */
router.post('/full-create', verifyToken, createAgentWithUser);

/**
 * @swagger
 * /api/agents/full-update/{userId}:
 *   patch:
 *     summary: Full update for agent and user profile
 *     tags: [Agent]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *               skills:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       200:
 *         description: Agent and user updated
 */
router.patch('/full-update/:userId', verifyToken, updateAgentWithUser);

module.exports = router;
