const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');
const verifyToken = require('../middleware/authMiddleware');

const {
  createTicket,
  getTickets,
  getTicketById,
  updateTicket,
  escalateTicket,
  getSLAViolations,
  getSlaViolationsForAgent,
  attachFiles,
  agentUpdateTicket,
  getLinkedIncidents,
  getEscalatedTickets,
  getCSATStats,
  getAgentWorkloadStats,
  getAllTicketsForAdmin,
  assignTicketManually,
  deleteTicket,
  addInternalNote,
  submitFeedback
} = require('../controllers/ticket.controller');

/**
 * @swagger
 * tags:
 *   name: Tickets
 *   description: Ticket management API
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     Ticket:
 *       type: object
 *       required:
 *         - subject
 *         - description
 *         - customerId
 *       properties:
 *         subject:
 *           type: string
 *         description:
 *           type: string
 *         priority:
 *           type: string
 *           enum: [low, medium, high, critical]
 *         complexity:
 *           type: string
 *           enum: [simple, moderate, complex]
 *         category:
 *           type: string
 *         domain:
 *           type: string
 *         product:
 *           type: string
 *         operationType:
 *           type: string
 *         region:
 *           type: string
 *         country:
 *           type: string
 *         account:
 *           type: string
 *         skillRequired:
 *           type: array
 *           items:
 *             type: string
 *         tags:
 *           type: array
 *           items:
 *             type: string
 *         securityRestriction:
 *           type: boolean
 *         status:
 *           type: string
 *           enum: [new, assigned, in_progress, waiting_customer, resolved, closed]
 *         customerId:
 *           type: string
 *         assignedTo:
 *           type: string
 */

/**
 * @swagger
 * /tickets:
 *   post:
 *     summary: Create a new ticket
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Ticket'
 *     responses:
 *       200:
 *         description: Ticket created successfully
 */
router.post('/', verifyToken, createTicket);

/**
 * @swagger
 * /tickets:
 *   get:
 *     summary: Get tickets for current user
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of tickets
 */
router.get('/', verifyToken, getTickets);

/**
 * @swagger
 * /tickets/sla/violations:
 *   get:
 *     summary: Get SLA violations
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: SLA violations
 */
router.get('/sla/violations', verifyToken, getSLAViolations);
router.get('/overdue/:agentId',verifyToken, getSlaViolationsForAgent);

/**
 * @swagger
 * /tickets/linked-incidents:
 *   get:
 *     summary: Get linked incidents
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.get('/linked-incidents', verifyToken, getLinkedIncidents);

/**
 * @swagger
 * /tickets/escalated:
 *   get:
 *     summary: Get escalated tickets
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.get('/escalated', verifyToken, getEscalatedTickets);

/**
 * @swagger
 * /tickets/analytics/csat:
 *   get:
 *     summary: Get CSAT stats
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.get('/analytics/csat', verifyToken, getCSATStats);

/**
 * @swagger
 * /tickets/workload:
 *   get:
 *     summary: Get agent workload statistics
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.get('/workload', verifyToken, getAgentWorkloadStats);

/**
 * @swagger
 * /tickets/{id}:
 *   get:
 *     summary: Get ticket by ID
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: Ticket ID
 *         schema:
 *           type: string
 */
router.get('/:id', verifyToken, getTicketById);

/**
 * @swagger
 * /tickets/{id}:
 *   patch:
 *     summary: Update ticket details
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: Ticket ID
 *         schema:
 *           type: string
 */
router.patch('/:id', verifyToken, updateTicket);
router.delete('/:id', verifyToken, deleteTicket);
/**
 * @swagger
 * /tickets/{id}/agent-update:
 *   patch:
 *     summary: Agent updates ticket status or notes
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.patch('/:id/agent-update', verifyToken, agentUpdateTicket);

/**
 * @swagger
 * /tickets/{id}/escalate:
 *   post:
 *     summary: Escalate a ticket
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.post('/:id/escalate', verifyToken, escalateTicket);

/**
 * @swagger
 * /tickets/{id}/attach:
 *   post:
 *     summary: Upload attachments to a ticket
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               files:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 */
router.post('/:id/attach', verifyToken, upload.array('files'), attachFiles);

/**
 * @swagger
 * /tickets/admin/all:
 *   get:
 *     summary: Get all tickets (admin only)
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.get('/admin/all', verifyToken, getAllTicketsForAdmin);

/**
 * @swagger
 * /tickets/admin/assign:
 *   post:
 *     summary: Manually assign a ticket (admin)
 *     tags: [Tickets]
 *     security:
 *       - bearerAuth: []
 */
router.post('/admin/assign', verifyToken, assignTicketManually);
router.post('/:ticketId/internal-note', verifyToken,addInternalNote);
// POST: Submit feedback (CSAT rating) for a ticket
router.put('/:ticketId/feedback', verifyToken, submitFeedback);
module.exports = router;
