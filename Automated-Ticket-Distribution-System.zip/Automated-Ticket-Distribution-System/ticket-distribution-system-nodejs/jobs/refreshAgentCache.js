const Agent = require('../models/agent.model');
const redisClient = require('../utils/redisClient');

async function refreshAgentCache() {
  const agents = await Agent.find({ availability: 'online' });

  for (const agent of agents) {
    const key = `agent:${agent._id}`;

    // Always ensure key is a proper hash
    await redisClient.del(key);

    await redisClient.hSet(key, {
      skills: JSON.stringify(agent.skills),
      domainExpertise: JSON.stringify(agent.domainExpertise),
      workload: agent.workload,
      experience: agent.experience
    });
  }

  console.log(`[CRON] Refreshed agent cache for ${agents.length} agents`);
}

module.exports = refreshAgentCache;
