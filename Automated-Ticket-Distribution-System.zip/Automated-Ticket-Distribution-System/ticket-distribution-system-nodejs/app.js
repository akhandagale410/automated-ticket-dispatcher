const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes')
const ticketRoutes = require('./routes/ticketRoutes');
const agentRoutes = require('./routes/agentRoutes');
const customerRoutes = require('./routes/customerRoutes');
const yaml = require('js-yaml');
require('dotenv').config();
const app = express();
const cors = require('cors');
const { swaggerUi, swaggerSpec } = require('./swagger');
app.use(cors({
  origin: 'http://localhost:4200',
  credentials: true // optional: for cookies or auth headers
}));
// Middleware
app.use(express.json());  // Built-in middleware for parsing JSON
app.use(bodyParser.urlencoded({ extended: true })); // URL-encoded data support
const cron = require('node-cron');
const refreshAgentCache = require('./jobs/refreshAgentCache');
// MongoDB connection
mongoose.connect(process.env.DB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('Error connecting to MongoDB:', err));

// Routes
app.use('/api', userRoutes);
app.use('/api/tickets', ticketRoutes);
app.use('/api/agents', agentRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.get('/swagger.yaml', (req, res) => {
  const yamlStr = yaml.dump(swaggerSpec);
  res.setHeader('Content-Type', 'application/x-yaml');
  res.send(yamlStr);
});
cron.schedule('*/5 * * * *', () => {
  refreshAgentCache();
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

